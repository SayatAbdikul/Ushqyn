"""All-INT8-input accumulation bounds for the selected grouped KWS/VWW graphs."""
import hashlib
import json
import math
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[3]
sys.path[:0] = [str(ROOT / 'tools/phase6'), str(ROOT / 'compiler')]
from run_boardless import load_model
from followup_graph import group_channels


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def report():
    result = {'method': 'For raw signed INT8 x, every prefix lies in [bias + sum(min(-128*w,127*w)), bias + sum(max(-128*w,127*w))]. Include initial bias and every prefix, matching the original eight-channel overflow checkpoints.', 'models': {}, 'source_sha256': {}}
    for name in ('kws', 'vww'):
        original, _, _, sources = load_model(name)
        graph, _, _ = group_channels(original)
        result['source_sha256'][name] = sources
        rows = []
        for index, layer in enumerate(graph.layers):
            if layer.op not in ('Conv', 'Gemm'):
                continue
            weights = np.asarray(layer.parameters['weight'], dtype=np.int64).reshape(len(layer.parameters['weight']), -1)
            biases = np.asarray(layer.parameters['corrected_bias'], dtype=np.int64)
            per_channel = []
            for c, (b, row) in enumerate(zip(biases, weights)):
                # Dense Conv zero filters are emitted as constant DMAs by
                # compile_constant_chain, so they never initialize PW_MAC.
                constant_filter = layer.op == 'Conv' and layer.attributes.get('group', 1) == 1 and not np.any(row)
                low = high = int(b)
                worst_low = low
                worst_high = high
                for weight in row:
                    w = int(weight)
                    low += min(-128*w, 127*w)
                    high += max(-128*w, 127*w)
                    worst_low = min(worst_low, low)
                    worst_high = max(worst_high, high)
                bits = next(width for width in range(2, 34) if -(1 << (width-1)) <= worst_low and worst_high <= (1 << (width-1))-1)
                per_channel.append({'channel': c, 'min_prefix': worst_low, 'max_prefix': worst_high, 'signed_bits': bits, 'compiler_constant_filter': bool(constant_filter)})
            active = [r for r in per_channel if not r['compiler_constant_filter']]
            rows.append({'layer': index, 'op': layer.op, 'shape': list(layer.parameters['weight'].shape), 'active_min_prefix': min(r['min_prefix'] for r in active), 'active_max_prefix': max(r['max_prefix'] for r in active), 'active_max_signed_bits': max(r['signed_bits'] for r in active), 'constant_filters': len(per_channel)-len(active), 'active_channels_requiring_gt21': sum(r['signed_bits'] > 21 for r in active), 'active_channels_requiring_gt24': sum(r['signed_bits'] > 24 for r in active), 'channels': per_channel})
        result['models'][name] = {'layers': rows, 'active_max_signed_bits': max(r['active_max_signed_bits'] for r in rows), 'active_min_prefix': min(r['active_min_prefix'] for r in rows), 'active_max_prefix': max(r['active_max_prefix'] for r in rows)}
    result['combined_active_max_signed_bits'] = max(v['active_max_signed_bits'] for v in result['models'].values())
    return result


if __name__ == '__main__':
    path = Path(__file__).with_name('proof.json')
    path.write_text(json.dumps(report(), indent=2, sort_keys=True) + '\n')
    print(json.dumps({k: {'active_max_signed_bits': v['active_max_signed_bits'], 'active_min_prefix': v['active_min_prefix'], 'active_max_prefix': v['active_max_prefix']} for k, v in json.loads(path.read_text())['models'].items()}, sort_keys=True))
