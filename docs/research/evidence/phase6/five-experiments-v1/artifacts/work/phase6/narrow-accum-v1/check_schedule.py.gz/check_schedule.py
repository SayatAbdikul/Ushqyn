"""Check that selected bytecode stages skip every large-bias zero filter."""
import hashlib
import json
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[3]
sys.path[:0] = [str(ROOT / 'tools/phase6'), str(ROOT / 'compiler')]
from run_boardless import load_model
from followup_graph import group_channels

BASE = Path(__file__).resolve().parent
SOURCE = ROOT / 'work/phase6/experiments-v1/fused-activation-v1/fixtures'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run():
    bound = json.loads((BASE / 'proof.json').read_text())
    report = {'status': 'passed', 'models': {}, 'proof_sha256': sha(BASE / 'proof.json')}
    for model in ('kws', 'vww'):
        graph, _, _ = group_channels(load_model(model)[0])
        expected = {}
        for index, layer in enumerate(graph.layers):
            if layer.op == 'Conv' and layer.attributes.get('group', 1) == 1:
                w = np.asarray(layer.parameters['weight'])
                expected[index] = tuple(bool(x) for x in np.all(w == 0, axis=(1, 2, 3)))
        fixtures = {}
        for sample in ('pinned-grouped-fused-timed', 'stress-grouped-fused-check'):
            path = SOURCE / f'{model}-{sample}' / 'schedule.json'
            schedule = json.loads(path.read_text())
            covered = {index: set() for index, mask in expected.items() if any(mask)}
            executed = {index: set() for index in covered}
            for stage in schedule['stages']:
                index = stage['layer']
                if index not in covered:
                    continue
                parts = stage.get('constant_filter_parts')
                if parts is None:
                    raise ValueError(f'{model} layer {index} bypassed constant-filter splitter')
                for part in parts:
                    first = part['first_channel']
                    last = first + part['channels']
                    for channel in range(first, last):
                        if channel >= len(expected[index]) or expected[index][channel] != part['constant']:
                            raise ValueError(f'{model} layer {index} channel {channel}: splitter mismatch')
                        covered[index].add(channel)
                        if not part['constant']:
                            executed[index].add(channel)
            for index, mask in expected.items():
                if any(mask) and covered[index] != set(range(len(mask))):
                    raise ValueError(f'{model} layer {index}: incomplete channel split')
                if any(mask) and any(mask[c] for c in executed[index]):
                    raise ValueError(f'{model} layer {index}: constant filter executed')
            fixtures[sample] = {'schedule_sha256': sha(path),
                                'constant_filters_skipped': sum(sum(mask) for mask in expected.values()),
                                'split_layers': len(covered)}
        model_bound = bound['models'][model]
        row = {'active_max_signed_bits': model_bound['active_max_signed_bits'],
               'spatial_acc_bits': max(x['active_max_signed_bits'] for x in model_bound['layers'] if x['op'] == 'Conv'),
               'dense_gemm_bits': max(x['active_max_signed_bits'] for x in model_bound['layers'] if x['op'] == 'Gemm'),
               'fixtures': fixtures}
        if row['spatial_acc_bits'] > 28:
            raise ValueError(f'{model}: 28-bit accumulator insufficient')
        report['models'][model] = row
    return report


if __name__ == '__main__':
    report = run()
    (BASE / 'schedule-proof.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
    print(json.dumps(report, sort_keys=True))
