"""Isolated model-specific accumulator-width experiment; never uses the board.

This bitstream is valid only for the certified grouped KWS/VWW programs.
The unchanged production image is the fallback for other weights/programs.
"""
import argparse
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
sys.path[:0] = [str(ROOT / 'tools/phase6'), str(ROOT / 'compiler')]
import combined_spec
import combined_scalar_uart
import fused_activation
import tail_mask

BASE = Path(__file__).resolve().parent
ENGINE = BASE / 'engine.sv'
SOURCE = ROOT / 'work/phase6/experiments-v1/fused-activation-v1/engine.sv'
SOURCE_BASE = SOURCE.parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def replace_once(text, old, new):
    if text.count(old) != 1:
        raise ValueError('patch site changed: ' + old[:60])
    return text.replace(old, new, 1)


def generated_engine():
    text = SOURCE.read_text()
    text = replace_once(text, '    parameter integer ACC_WORK_BITS = 33,',
                        '    parameter integer ACC_WORK_BITS = 33,\n    parameter integer PW_ACC_BITS = 28,')
    text = replace_once(text, 'logic signed [ACC_WORK_BITS-1:0] pw_acc[0:7],pw_next[0:7];',
                        'logic signed [PW_ACC_BITS-1:0] pw_acc[0:7],pw_next[0:7];')
    text = replace_once(text, "pw_next[k]=pw_acc[k]+{{(ACC_WORK_BITS-16){products[k][15]}},products[k]};",
                        "pw_next[k]=pw_acc[k]+{{(PW_ACC_BITS-16){products[k][15]}},products[k]};")
    text = replace_once(text, "pw_acc[k]<={{(ACC_WORK_BITS-32){p0[31]}},p0[31:0]};",
                        "pw_acc[k]<=p0[PW_ACC_BITS-1:0];")
    for base in ('pw_next[0]', 'pw_acc[pw_lane+3\'d1]', 'pw_acc[1]', 'pw_acc[q_issue_lane[2:0]+3\'d1]'):
        old = base + '[31:0]'
        new = "{{(32-PW_ACC_BITS){" + base + "[PW_ACC_BITS-1]}}," + base + "}"
        text = replace_once(text, old, new)
    return '// Certified model-specific 28-bit spatial accumulator; generic fallback is separate.\n' + text


def prepare():
    proof = json.loads((BASE / 'proof.json').read_text())
    if proof['combined_active_max_signed_bits'] != 28:
        raise ValueError('model bounds changed')
    text = generated_engine()
    if ENGINE.exists() and ENGINE.read_text() != text:
        raise ValueError('candidate engine changed')
    ENGINE.write_text(text)
    (BASE / 'fixtures.json').write_bytes((SOURCE_BASE / 'fixtures.json').read_bytes())
    record = {'source_sha256': sha(SOURCE), 'proof_sha256': sha(BASE / 'proof.json'),
              'engine_sha256': sha(ENGINE), 'fixture_manifest_sha256': sha(BASE / 'fixtures.json'),
              'scope': 'certified grouped KWS/VWW program images only; unchanged source engine for generic descriptors',
              'pw_acc_bits': 28, 'generic_acc_bits': 33}
    (BASE / 'identity.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
    combined_spec.runner.BASE = BASE
    combined_spec.runner.ENGINE = ENGINE
    combined_scalar_uart.BASE = BASE
    combined_scalar_uart.ENGINE = ENGINE
    fused_activation.BASE = BASE
    fused_activation.ENGINE = ENGINE
    fused_activation.FIXTURES = SOURCE_BASE / 'fixtures'
    tail_mask.BASE = BASE
    tail_mask.ENGINE = ENGINE
    return record


def native():
    return fused_activation.native()


def integration():
    return combined_scalar_uart.integration()


def route():
    return tail_mask.route_clock(24)


def compare():
    reference = json.loads((SOURCE_BASE / 'native/report.json').read_text())
    candidate = json.loads((BASE / 'native/report.json').read_text())
    original_route = json.loads((SOURCE_BASE / 'route24/report.json').read_text())
    new_route = json.loads((BASE / 'route24/report.json').read_text())
    assert reference['status'] == candidate['status'] == 'passed'
    assert new_route['status'] == 'passed-route'
    baseline = {(r['fixture'], r['stall_seed']): r for r in reference['results']}
    measured = {(r['fixture'], r['stall_seed']): r for r in candidate['results']}
    assert baseline.keys() == measured.keys()
    for key in baseline:
        for field in ('status', 'elapsed_cycles', 'engine_cycles', 'tensor_checks', 'fixture_files'):
            assert baseline[key][field] == measured[key][field], (key, field)
    before = {key: value['used'] for key, value in original_route['resources'].items()}
    after = {key: value['used'] for key, value in new_route['resources'].items()}
    result = {'status': 'passed-no-go', 'physical_board': False,
              'exact_fixture_runs': len(baseline), 'identical_cycles': True,
              'baseline_route': str((SOURCE_BASE / 'route24/report.json').relative_to(ROOT)),
              'candidate_route': str((BASE / 'route24/report.json').relative_to(ROOT)),
              'routed_fmax_mhz': {'original': original_route['routed_core_fmax_mhz'],
                                  'candidate': new_route['routed_core_fmax_mhz']},
              'resources_used': {'original': before, 'candidate': after,
                                 'delta': {key: after[key]-before[key] for key in before}},
              'generic_counterexample': {'bias': 2147483647, 'weight': 1, 'input': 1,
                  'original_33bit_next': 2147483648, 'original_error_code': 5,
                  'narrow_28bit_wrapped_next': 0,
                  'scope': 'an arbitrary legal descriptor; proves specialized image cannot replace generic fallback'},
              'decision': 'Do not select the model-specific narrowed image: no latency gain, four more CLS sites, lower Fmax and generic semantics require the original image.'}
    (BASE / 'comparison.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('stage', choices=('prepare', 'native', 'integration', 'route', 'compare'))
    stage = parser.parse_args().stage
    record = prepare()
    if stage == 'native': result = native()
    elif stage == 'integration': result = integration()
    elif stage == 'route': result = route()
    elif stage == 'compare': result = compare()
    else: result = record
    print(json.dumps({'stage': stage, 'status': result.get('status', 'prepared'),
                      'engine_sha256': sha(ENGINE)}, sort_keys=True), flush=True)
