#!/usr/bin/env python3
"""Strengthen frozen column-pruning controls with dev-only teacher regression.

No factor ranks or factors are altered. This is a software quality/control
experiment. Sparse column costs still assume compiler/hardware gathering or
propagated channel compaction, neither implemented by this driver.
"""
import os
for name in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS'):
    os.environ[name]='1'
import copy
import json
from pathlib import Path
import resource
import sys
import time
import numpy as np

ROOT=Path(__file__).resolve().parents[3]
sys.path[:0]=[str(ROOT/'tools/phase6'),str(ROOT/'compiler')]
import representation_screen as rs
from quantization import quantize_parameters


def main():
    report={'status':'running','scope':__doc__,'source_sha256':rs.digest(Path(__file__)),
            'factor_driver_sha256':rs.digest(Path(rs.__file__)),'models':{},
            'selection':'fixed selected columns, same rank-matched budget; no candidate ranking or heldout adaptation'}
    for name in ('kws','vww','ad'):
        start=time.perf_counter()
        folder=rs.BASE/name
        original_report=json.loads((folder/'report.json').read_text())
        ranks={int(i):r for i,r in original_report['selection']['selected_ranks'].items()}
        if name=='ad':
            program=rs.load_image((ROOT/'work/phase6/parallel-ad-v1/ad.uq2').read_bytes())
            archive=ROOT/'work/phase0-ad/features/ad.accuracy.npz'
        else:
            program=rs.load_model(name)[0]
            archive=ROOT/f'work/quality/{name}.accuracy.npz'
        features=rs.member(archive,program.inputs[0],folder/'mapped')
        labels=rs.member(archive,'recording_labels' if name=='ad' else 'labels',folder/'mapped')
        dev=np.array(original_report['selection']['dev_indices'])
        heldout=np.array(original_report['selection']['heldout_indices'])
        if name=='ad':
            recording_index=rs.member(archive,'recording_index',folder/'mapped')
            fit_indices=np.concatenate([np.flatnonzero(recording_index==r)[::25] for r in dev])
        else:
            fit_indices=dev
        rows=rs.spectra(program)
        covariance={r['layer']:np.zeros((r['ci'],r['ci']),float) for r in rows if r['layer'] in ranks}
        for index in fit_indices:
            x=program.tensors[program.inputs[0]].quantization.encode(np.asarray(features[index]))
            if name=='ad':x=x.reshape(1,-1)
            _,captures,_=rs.run(program,x,capture=True)
            for i,cov in covariance.items():
                matrix=captures[i]
                xx=matrix[np.linspace(0,len(matrix)-1,min(32,len(matrix)),dtype=int)]
                cov+=xx.astype(float).T@xx.astype(float)
        refit=copy.deepcopy(program)
        details=[]
        for row in rows:
            i=row['layer']
            if i not in ranks:continue
            p=program.layers[i].parameters
            w=p['weight'].reshape(row['co'],row['ci']).astype(float)*p['weight_scales'][:,None]
            cov=covariance[i]
            budget=ranks[i]*(row['ci']+row['co'])
            keep=min(row['ci'],max(1,budget//row['co']))
            importance=np.sum(w*w,axis=0)*np.diag(cov)
            columns=np.argsort(importance)[-keep:]
            ckk=cov[np.ix_(columns,columns)]
            ridge=max(float(np.trace(ckk)/len(ckk))*1e-6,1e-8)
            target=w@cov[:,columns]
            retained=np.linalg.solve(ckk+ridge*np.eye(keep),target.T).T
            fitted=np.zeros_like(w)
            fitted[:,columns]=retained
            layer=program.layers[i]
            iq=program.tensors[layer.inputs[0]].quantization
            oq=program.tensors[layer.output].quantization
            bias=p['bias'].astype(float)*iq.scale*p['weight_scales']
            fitted=fitted.reshape(p['weight'].shape)
            refit.layers[i].parameters=quantize_parameters(fitted,bias,iq,oq)
            error=w-fitted.reshape(w.shape)
            details.append({'layer':i,'retained_columns':columns.tolist(),'weight_budget_bytes':budget,
                            'actual_column_weight_bytes':row['co']*keep,
                            'fit_relative_squared_error':float(np.sum((error@cov)*error)/max(np.sum((w@cov)*w),1e-30))})
        # Program serialization validates every integer raw-accumulation bound.
        executable=rs.build_image(refit)
        (folder/'matched-column-pruning-refit.uq2').write_bytes(executable)
        if name=='ad':
            dev_quality,dev_scores=rs.eval_ad(refit,features,recording_index,labels,dev,{'refit':{}})
            quality,scores=rs.eval_ad(refit,features,recording_index,labels,heldout,{'refit':{}})
        else:
            dev_quality,dev_scores=rs.eval_class(refit,features,labels,dev,{'refit':{}})
            quality,scores=rs.eval_class(refit,features,labels,heldout,{'refit':{}})
        checks=[]
        for index in fit_indices[:2]:
            x=refit.tensors[refit.inputs[0]].quantization.encode(np.asarray(features[index]))
            expected=rs.oracle(refit,{refit.inputs[0]:x})
            _,_,actual=rs.run(refit,x,capture=True)
            if any(not np.array_equal(expected[l.output],actual[l.output]) for l in refit.layers):
                raise AssertionError('refit oracle mismatch')
            checks.append(int(index))
        row={'factor_report_sha256':rs.digest(folder/'report.json'),'archive_sha256':rs.digest(archive),
             'details':details,'dev_quality':dev_quality['refit'],'heldout_quality':quality['refit'],
             'integer_oracle_all_layer_checks':checks,'fit_samples':len(fit_indices),
             'executable_sha256':rs.digest(folder/'matched-column-pruning-refit.uq2'),
             'cost':original_report['heldout_costs']['matched-column-pruning'],
             'elapsed_seconds':time.perf_counter()-start,
             'limitation':'full zero-column INT8 executable; reported sparse operation cost requires gather/channel-compaction lowering, not implemented'}
        report['models'][name]=row
        rs.save(folder/'pruning-refit-report.json',row)
        rs.save(folder/'pruning-refit-predictions.json',{'dev':dev_scores,'heldout':scores})
        rs.save(rs.BASE/'pruning-refit-report.json',report)
        print(name,'refit completed',quality,flush=True)
        del features,labels,covariance,refit,program
    report['status']='completed-software-control'
    report['peak_rss_bytes']=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*(1 if sys.platform=='darwin' else 1024)
    rs.save(rs.BASE/'pruning-refit-report.json',report)


if __name__=='__main__':main()
