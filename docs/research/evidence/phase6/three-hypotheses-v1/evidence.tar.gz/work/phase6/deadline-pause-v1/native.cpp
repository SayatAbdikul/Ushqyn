// Full command-sequencer/engine/SRAM/DMA simulation with a stalled RAM port.
// External RAM is a test model, not the electrical SDRAM controller.
#include "Vv2_tiled_host_bridge.h"
#include "Vv2_tiled_host_bridge___024root.h"
#include "verilated.h"
#include <algorithm>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <iterator>
#include <random>
#include <map>
#include <stdexcept>
#include <string>
#include <vector>
using Bytes=std::vector<uint8_t>;
static Vv2_tiled_host_bridge d;
static Bytes memory(8*1024*1024);
static std::mt19937 rng;
static bool stalls=false,pending=false,held=false;
static unsigned delay=0,sequence_id=0;
static uint64_t pending_data=0,cycles=0;
struct Request { uint32_t addr; uint64_t data; unsigned wr,mask; };
static Request hold;
static void require(bool b,const std::string& s){if(!b)throw std::runtime_error(s);}
static Bytes file(const std::string& s){std::ifstream f(s,std::ios::binary);require(bool(f),"missing "+s);return Bytes(std::istreambuf_iterator<char>(f),{});}
static uint32_t u32(const Bytes& b,unsigned i){return uint32_t(b.at(i))|uint32_t(b.at(i+1))<<8|uint32_t(b.at(i+2))<<16|uint32_t(b.at(i+3))<<24;}
static uint16_t crc(const Bytes& b,unsigned first,unsigned end){uint16_t c=65535;for(unsigned i=first;i<end;i++){c^=uint16_t(b[i])<<8;for(int k=0;k<8;k++)c=c&0x8000?(c<<1)^0x1021:c<<1;}return c;}
static void observe_pause();
static int step(){
    d.clk=0; bool ready=!pending&&(!stalls||rng()%5!=0);
    d.ext_ready=ready;d.ext_rvalid=0;
    if(pending){if(delay==0){d.ext_rvalid=1;d.ext_rdata=pending_data;pending=false;}else delay--;}
    d.eval();int out=d.tx_valid&&d.tx_ready?d.tx_data:-1;
    Request r{d.ext_addr,d.ext_wdata,d.ext_wr,d.ext_wstrb};
    if(held)require(d.ext_req&&r.addr==hold.addr&&r.data==hold.data&&r.wr==hold.wr&&r.mask==hold.mask,"unstable external request");
    held=d.ext_req&&!ready;if(held)hold=r;
    if(d.ext_req&&ready){
        require(r.addr%8==0&&r.addr+8<=memory.size(),"external range/alignment");
        if(r.wr){for(unsigned k=0;k<8;k++)if(r.mask>>k&1)memory[r.addr+k]=r.data>>(k*8);}
        else{require(!pending,"overlapping RAM reads");pending=true;delay=stalls?rng()%5:0;pending_data=0;for(unsigned k=0;k<8;k++)pending_data|=uint64_t(memory[r.addr+k])<<(k*8);}
    }
    d.clk=1;d.eval();cycles++;observe_pause();return out;
}
static Bytes command(unsigned cmd,uint32_t addr=0,const Bytes& data={},unsigned length=0){
    if(cmd==3)length=data.size();unsigned seq=sequence_id++&255;
    Bytes b={0xa5,0x5a,2,uint8_t(cmd),uint8_t(seq),uint8_t(addr),uint8_t(addr>>8),uint8_t(addr>>16),uint8_t(length),uint8_t(length>>8)};
    b.insert(b.end(),data.begin(),data.end());auto c=crc(b,2,b.size());b.push_back(c);b.push_back(c>>8);
    d.tx_ready=0;d.rx_valid=1;for(auto byte:b){d.rx_data=byte;step();}d.rx_valid=0;d.tx_ready=1;
    Bytes reply;unsigned total=0;
    for(unsigned n=0;n<100000;n++){int byte=step();if(byte>=0)reply.push_back(byte);if(reply.size()==10)total=12+reply[8]+(unsigned(reply[9])<<8);if(total&&reply.size()==total)break;}
    require(total&&reply.size()==total,"protocol timeout");
    require(reply[0]==0xa5&&reply[1]==0x5a&&reply[2]==2&&reply[3]==(cmd|128)&&reply[4]==seq,"reply header");
    require(crc(reply,2,reply.size()-2)==(unsigned(reply[reply.size()-2])|(unsigned(reply.back())<<8)),"reply CRC");
    require(reply[10]==0,"command rejected "+std::to_string(reply[10]));
    return Bytes(reply.begin()+11,reply.end()-2);
}

static unsigned phase=0;
struct Span { unsigned phase; uint64_t start,end; unsigned elapsed,engine,dma,overlap; };
static std::vector<Span> spans;
static uint64_t accepted_cycle=0,paused_cycle=0;
static bool previous_pause_request=false,previous_paused=false;
static void observe_pause(){
    auto* r=d.rootp;
    bool request=r->v2_tiled_host_bridge__DOT__seq_pause_req;
    bool paused=r->v2_tiled_host_bridge__DOT__seq_paused;
    if(request&&!previous_pause_request)accepted_cycle=cycles;
    if(paused&&!previous_paused){
        require(!r->v2_tiled_host_bridge__DOT__seq_busy&&!d.engine_busy&&!d.dma_busy&&
                !r->v2_tiled_host_bridge__DOT__dma_pending&&!pending,
                "pause was not fully drained");
        paused_cycle=cycles;
    }
    previous_pause_request=request;previous_paused=paused;
}
static Bytes sram_snapshot(){
    Bytes out(32768);auto* r=d.rootp;
    for(unsigned i=0;i<4096;i++){
                out[i*8+0]=r->v2_tiled_host_bridge__DOT__core__DOT__memory__DOT__banks__BRA__0__KET____DOT__ram[i];
        out[i*8+1]=r->v2_tiled_host_bridge__DOT__core__DOT__memory__DOT__banks__BRA__1__KET____DOT__ram[i];
        out[i*8+2]=r->v2_tiled_host_bridge__DOT__core__DOT__memory__DOT__banks__BRA__2__KET____DOT__ram[i];
        out[i*8+3]=r->v2_tiled_host_bridge__DOT__core__DOT__memory__DOT__banks__BRA__3__KET____DOT__ram[i];
        out[i*8+4]=r->v2_tiled_host_bridge__DOT__core__DOT__memory__DOT__banks__BRA__4__KET____DOT__ram[i];
        out[i*8+5]=r->v2_tiled_host_bridge__DOT__core__DOT__memory__DOT__banks__BRA__5__KET____DOT__ram[i];
        out[i*8+6]=r->v2_tiled_host_bridge__DOT__core__DOT__memory__DOT__banks__BRA__6__KET____DOT__ram[i];
        out[i*8+7]=r->v2_tiled_host_bridge__DOT__core__DOT__memory__DOT__banks__BRA__7__KET____DOT__ram[i];
    }
    return out;
}
static void entry(unsigned pc){
    command(3,0x41001c,{uint8_t(pc),uint8_t(pc>>8)});
}
static Bytes run_sequence(unsigned pc,unsigned tag){
    phase=tag;entry(pc);uint64_t start=cycles;
    command(3,0x410000,{1});
    unsigned ticks=0;while(d.rootp->v2_tiled_host_bridge__DOT__seq_busy&&ticks++<200000000)step();
    require(ticks<200000000,"sequence timeout");
    auto regs=command(2,0x410000,{},32);
    require(regs.size()==32&&regs[0]==0&&regs[1]==0,"sequence failed, error "+std::to_string(regs.at(1)));
    spans.push_back({tag,start,cycles,u32(regs,8),u32(regs,12),u32(regs,16),u32(regs,20)});
    return regs;
}
static void temporary_program(unsigned entrypc,const Bytes& program){
    require(entrypc*16+program.size()<=32768,"temporary program capacity");
    for(unsigned i=0;i<program.size();i+=64)
        command(3,0x500000+entrypc*16+i,Bytes(program.begin()+i,
            program.begin()+std::min(unsigned(program.size()),i+64)));
}
static void append32(Bytes& bytes,uint32_t v){for(unsigned k=0;k<4;k++)bytes.push_back(v>>(k*8));}
static void emit(Bytes& program,unsigned op,unsigned flag,unsigned a=0,unsigned b=0,unsigned c=0){
    program.insert(program.end(),{uint8_t(op),uint8_t(flag),0,0});
    append32(program,a);append32(program,b);append32(program,c);
}
static Bytes context_program(const std::vector<std::pair<unsigned,unsigned>>& ranges,
                             unsigned contextbase,bool restore){
    Bytes program;
    for(auto [base,length]:ranges){emit(program,1,restore,contextbase+base,base,length);emit(program,3,2);}
    emit(program,0,0);return program;
}
int main(int argc,char** argv){try{
    Verilated::commandArgs(argc,argv);require(argc==5,"fixture directory, seed, report, mode required");
    std::string dir=argv[1];unsigned seed=std::stoul(argv[2]),mode=std::stoul(argv[4]);
    stalls=seed!=0;rng.seed(seed);
    auto payload=file(dir+"/payload.bin"),program=file(dir+"/commands.bin");
    require(payload.size()<=memory.size(),"payload capacity");std::copy(payload.begin(),payload.end(),memory.begin());
    unsigned adentry,tempentry,contextbase,clobberbase,release,relative_deadline;
    std::ifstream cf(dir+"/control.txt");cf>>adentry>>tempentry>>contextbase>>clobberbase>>release>>relative_deadline;
    require(bool(cf),"invalid control manifest");
    std::map<unsigned,std::vector<std::pair<unsigned,unsigned>>> live;
    std::ifstream lf(dir+"/live.txt");unsigned pc,n;
    while(lf>>pc>>n){auto& r=live[pc];for(unsigned i=0;i<n;i++){unsigned b,c;lf>>b>>c;r.emplace_back(b,c);}}
    require(!live.empty(),"empty boundary liveness");
    d.rst_n=0;d.rx_valid=0;d.tx_ready=0;d.memory_initialized=1;d.memory_port_busy=0;
    for(int k=0;k<4;k++)step();d.rst_n=1;for(int k=0;k<4;k++)step();
    for(unsigned i=0;i<program.size();i+=64)
        command(3,0x500000+i,Bytes(program.begin()+i,program.begin()+std::min(unsigned(program.size()),i+64)));
    uint64_t release_cycle=0,ad_done=0,vww_start=0,vww_done=0,save_native=0,restore_native=0,clobber_native=0;
    unsigned resume=0,saved_bytes=0,mismatches=0,pause_wait=0,busy_guard_checks=0;
    if(mode==3){
        auto regs=run_sequence(0,1);
        save_native=u32(regs,8);
    }else{
        phase=1;entry(0);vww_start=cycles;command(3,0x410000,{1});
        for(unsigned address:{0x500000u,0u,0x410000u}){
            bool rejected=false;
            try{command(3,address,{0});}
            catch(const std::runtime_error& e){rejected=std::string(e.what())=="command rejected 3";}
            require(rejected,"busy mutation guard failed");busy_guard_checks++;
        }
        unsigned ticks=0;
        while(d.rootp->v2_tiled_host_bridge__DOT__seq_elapsed<release&&
              d.rootp->v2_tiled_host_bridge__DOT__seq_busy&&ticks++<200000000)step();
        require(ticks<200000000&&d.rootp->v2_tiled_host_bridge__DOT__seq_busy,"release occurred after VWW completion");
        release_cycle=cycles;command(3,0x410000,{2});
        ticks=0;while(d.rootp->v2_tiled_host_bridge__DOT__seq_busy&&ticks++<200000000)step();
        require(ticks<200000000,"pause timeout");
        auto regs=command(2,0x410000,{},32);
        require(regs[1]==0&&regs[2]==1,"pause status/error");
        resume=u32(regs,24);require(live.count(resume),"pause is not a declared drained boundary");
        require(resume==d.rootp->v2_tiled_host_bridge__DOT__seq_resume_index,"resume PC not exposed consistently");
        require(accepted_cycle&&paused_cycle>=accepted_cycle,"missing pause edges");
        pause_wait=paused_cycle-accepted_cycle;
        spans.push_back({1,vww_start,cycles,u32(regs,8),u32(regs,12),u32(regs,16),u32(regs,20)});
        auto before=sram_snapshot();auto ranges=live[resume];
        for(auto [base,length]:ranges)saved_bytes+=length;
        temporary_program(tempentry,context_program(ranges,contextbase,false));
        regs=run_sequence(tempentry,2);save_native=u32(regs,8);
        if(mode==1||mode==2){
            Bytes clear;emit(clear,1,1,clobberbase,0,32768);emit(clear,3,2);emit(clear,0,0);
            temporary_program(tempentry,clear);regs=run_sequence(tempentry,3);clobber_native=u32(regs,8);
            auto cleared=sram_snapshot();require(std::all_of(cleared.begin(),cleared.end(),[](auto v){return v==0xa5;}),"clobber DMA did not overwrite scratchpad");
        }
        run_sequence(adentry,4);ad_done=cycles;
        if(mode!=2){
            temporary_program(tempentry,context_program(ranges,contextbase,true));
            regs=run_sequence(tempentry,5);restore_native=u32(regs,8);
            auto after=sram_snapshot();
            for(auto [base,length]:ranges)for(unsigned i=base;i<base+length;i++)mismatches+=before[i]!=after[i];
            require(mismatches==0,"live scratchpad restore changed bytes");
        }
        run_sequence(resume,6);vww_done=cycles;
    }
    std::ifstream checks(dir+"/checks.txt");unsigned address,nchecks=0;std::string name;
    while(checks>>address>>name){
        if(mode==3&&name!="vww-output.bin")continue;
        auto expected=file(dir+"/"+name);require(address+expected.size()<=memory.size(),"check range");
        for(unsigned i=0;i<expected.size();i++)require(memory[address+i]==expected[i],"output mismatch "+name+" byte "+std::to_string(i));nchecks++;
    }
    require(nchecks==(mode==3?1:2),"missing exact output checks");
    std::ofstream report(argv[3]);
    report<<"{\"status\":\"passed\",\"physical_board\":false,\"seed\":"<<seed<<",\"mode\":"<<mode
          <<",\"tensor_checks\":"<<nchecks<<",\"busy_guard_checks\":"<<busy_guard_checks<<",\"pause_resume_index\":"<<resume<<",\"saved_live_dma_bytes\":"<<saved_bytes
          <<",\"restored_byte_mismatches\":"<<mismatches<<",\"release_cycle\":"<<release_cycle
          <<",\"accepted_cycle\":"<<accepted_cycle<<",\"paused_cycle\":"<<paused_cycle
          <<",\"pause_wait_cycles\":"<<pause_wait<<",\"ad_response_global_native_cycles\":"<<(ad_done?ad_done-release_cycle:0)
          <<",\"ad_relative_deadline_cycles\":"<<relative_deadline<<",\"ad_deadline_missed\":"<<(ad_done&&ad_done-release_cycle>relative_deadline?"true":"false")
          <<",\"vww_completion_global_native_cycles\":"<<(vww_done?vww_done-vww_start:0)
          <<",\"save_sequence_native_cycles\":"<<save_native<<",\"restore_sequence_native_cycles\":"<<restore_native
          <<",\"clobber_sequence_native_cycles\":"<<clobber_native<<",\"program_bytes\":"<<program.size()<<",\"spans\":[";
    for(unsigned i=0;i<spans.size();i++){
        if(i)report<<",";auto s=spans[i];
        report<<"{\"phase\":"<<s.phase<<",\"start\":"<<s.start<<",\"end\":"<<s.end<<",\"elapsed\":"<<s.elapsed
              <<",\"engine\":"<<s.engine<<",\"dma\":"<<s.dma<<",\"overlap\":"<<s.overlap<<"}";
    }
    report<<"]}\n";
    std::cout<<dir<<" mode "<<mode<<" seed "<<seed<<" exact outputs passed"<<std::endl;
    d.final();return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<std::endl;return 1;}}
