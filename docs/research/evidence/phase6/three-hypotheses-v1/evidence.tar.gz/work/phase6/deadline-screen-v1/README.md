# Bounded deadline-aware discrete-job screen

Completed 2026-10-01. The selected co-issue engine is unchanged. No production
RTL, board image, model, or host protocol was modified or programmed.

There is a conditional QoS opportunity: smaller independent output-channel
descriptors reduce blocking, but they increase isolated service time and live
checkpoint data. The current host/control path does not yet implement the
low-cost interruption assumed in favorable schedule cases. This screen does
not establish a new architecture contribution or physical schedulability.

## Actual native evidence

The source-pinned selected engine has SHA-256
`9f934dcc27ae891e4c7b8b84bcc4b65e82d903492c1867572784fbe1cd9484ee`.
Sources and fixture files are verified against the existing passed report in
the selected worktree. An isolated tracing harness records every command's
native sequencer interval. It uses the unchanged eight-MAC engine and abstract
external RAM, not an earlier analytical engine cost model.

There are 18 passed native runs: KWS, VWW and AD, each with baseline and two
split targets, under fixed RAM and seeded stalled RAM (0 and 6063). Every run
checks the exact final INT8 output against its real fixture oracle. AD timing
removes diagnostic snapshot stores from the existing fully checked fixture;
its arithmetic and inference dependencies remain unchanged. The original AD
fixture checked all layers separately. The split tests use one real pinned
sample per model; they are not an accuracy campaign.

| Model / variant | Fixed-RAM cycles | Largest safe quantum | Program bytes | Maximum live SRAM bytes | Maximum unbacked output bytes |
|---|---:|---:|---:|---:|---:|
| KWS baseline | 1,099,170 | 185,013 | 1,744 | 13,504 | 8,000 |
| KWS split25k | 1,128,977 | 24,463 | 4,928 | 16,204 | 15,500 |
| KWS split50k | 1,116,629 | 50,593 | 3,392 | 16,204 | 15,500 |
| VWW baseline | 2,014,205 | 154,043 | 15,568 | 19,984 | 19,200 |
| VWW split25k | 2,122,886 | 29,444 | 21,568 | 28,008 | 27,600 |
| VWW split50k | 2,038,598 | 50,203 | 19,168 | 23,304 | 22,800 |
| AD baseline / both splits | 294,419 | 19,580 | 4,144 | 32,512 | 224 |

The 25k targets increase isolated KWS/VWW service by 2.712%/5.396%; the 50k
targets increase it by 1.588%/1.211%. AD is already below both targets and is
unchanged. These are native device-cycle changes, not board measurements.
The selected board totals remain 1,119,142 KWS / 2,157,255 VWW at 27 MHz;
they are not silently substituted for the native command intervals.

Splitting uses complete independent output channels or GEMM rows, preserving
all INT8 quantization boundaries. Full original inputs, weights and parameters
remain in scratchpad. Each extra RUN charges descriptor DMA, descriptor fetch,
mandatory fused-activation table reload, and any changed overlap through actual
native execution. Depthwise channel groups obey the existing eight-byte input
alignment requirement; hence a requested target is not always achievable.

## Checkpoint validity and transport

An independent byte-version replay decodes the actual DMA/RUN/WAIT command
bytes and descriptors. Backward liveness uses descriptor operands, exact
spatial input footprints, output extents, and validation/epilogue records.
At each drained boundary it distinguishes data already backed in private
external memory from outputs that need saving before another job clobbers
scratchpad. Reload and save traffic round to eight-byte DMA granules.

The destructive clobber audit passes at 2,427 boundaries: replacing all bytes
outside the computed live set cannot reach a later semantic read before those
bytes are overwritten. This is a preservation proof within the declared
operand-access model. It is not a minimum-state theorem allowing compression,
recomputation or value-dependent reasoning, and it does not prove interleaved
RTL pause/resume correctness. Engine caches are invalidated per new descriptor;
no mid-descriptor accumulator checkpoint is assumed.

All compared schedules receive identical released jobs, deadlines, native
service traces and overhead rules. The grid contains 27 periodic scenarios
and 16 urgent-arrival scenarios, two RAM traces, four DMA costs (4/8/16/32
cycles per eight-byte word), four fixed owner-change costs
(0/256/4096/50000 cycles), and three program-transport modes. There are
4,128 paired sensitivity cases and 20,640 recorded schedules. Static slots
are selected from four tested sizes using the best miss/lateness result.

The strong descriptor EDF control is granted the same hypothetical low-cost
pause interface as split EDF. Neither is existing board functionality. It
can yield after all engine/DMA-drained WAIT boundaries, rather than only at
layer ends. Nonpreemptive EDF and static slots are additional controls.

| Program mode / split target | Fewer misses than descriptor EDF | More misses | Zero-miss rescues | Paired cases |
|---|---:|---:|---:|---:|
| Resident / 25k | 211 | 232 | 54 | 1,376 |
| Resident / 50k | 176 | 146 | 35 | 1,376 |
| Word-reload proxy / 25k | 174 | 321 | 39 | 1,376 |
| Word-reload proxy / 50k | 187 | 172 | 38 | 1,376 |
| Selected UART program reload / either | 0 | 0 | 0 | 1,376 |

These counts are synthetic scenario coverage, not the frequency of benefits
in deployment. Uniform finer splitting is not a universal improvement.
In all UART-reload schedules some deadline is missed: zero-miss count is zero
for every policy and variant. Program-memory writes on the selected physical
image use <=64-byte packets at 750,000 baud; 256-byte burst writes apply only
to SDRAM. The UART mode charges request/reply framing and a start command,
but omits additional polling and pause traffic, so it is already optimistic.

Resident programs require private job activation namespaces and compatible
command addressing. The combined baseline / 25k / 50k program sizes are
21,456 / 30,640 / 26,704 bytes. A software implementation inserting HALT
at every safe boundary instead needs 31,824 / 45,936 / 40,016 bytes: both
uniform split programs exceed the 32 KiB combined resident program capacity.
Such HALT software also pays host dispatch at every visited HALT, even if no
new job is selected; favorable pause-interface results omit that extra cost.
Multiple pending instances may need further program copies or address remapping.

## Concrete witnesses and stopping gate

`witnesses.json` contains each exact release/deadline sequence and complete
service/switch trace. For urgent AD arriving at 80% of VWW service, with an AD
deadline of 1.2 times its isolated cost, fixed RAM, eight cycles per DMA word,
256 fixed cycles, and word-proxy program reload:

* Descriptor EDF: AD response 400,422 cycles; one missed deadline.
* Split25k EDF: AD response 327,409 cycles; zero misses.
* Total transport/control overhead grows from 55,456 to 72,624 cycles.
* KWS response grows from 1,704,677 to 1,860,333 cycles.

Thus the mechanism trades other jobs' latency and additional state traffic for
an urgent job's deadline. It does not produce a single-inference speedup.
`break-even.json` samples additional fixed switch cost for both witnesses;
the 25k witness survives a sampled 38,000-cycle fixed cost, while the tighter
50k witness tolerates much less. The samples are not monotonic proofs.

Gate: retain this direction only if a small pause/controller implementation,
selective splitting and resident command addressing can fit, and calibrated
context traffic retains an advantage over descriptor EDF. Reject universal
fine-grained splitting and software UART program reload as the central claim.
Preemption and output blocking are established mechanisms; this screen is a
feasibility result, not evidence that their combination alone is novel.

## Reproduction and artifacts

```
.venv/bin/python3 tools/phase6/deadline_screen.py test
.venv/bin/python3 tools/phase6/deadline_screen.py run
```

`schedule` reruns only the bounded scheduling grid from measured `profiles.json`.
`--only-program-mode uart_reload` replaces that mode while retaining the other
results. No model accuracy arrays are loaded. Python observed peak RSS is
about 129 MiB; native builds use two compiler jobs and one fixed 8 MiB external
RAM model per run. No unbounded schedules or training run are launched.

* `evidence.json`: source/fixture hashes and all 18 native results.
* `native-build/identity.json`: selected sources and isolated tracing executable.
* `native/*.trace.json`: per-command native intervals and drained-unit states.
* `profiles.json`: quanta and context-byte requirements.
* `checkpoint-audit.json`: all destructive clobber checks.
* `results.json`, `witnesses.json`, `break-even.json`, `report.json`: screen results.
* `tests.log`: five passing invariant tests.
