#!/usr/bin/env python3
"""Paired exploratory bootstrap intervals; not a confirmatory quality test."""
import json
import os
from pathlib import Path
import sys
for name in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS'):
    os.environ[name]='1'
import numpy as np
ROOT=Path(__file__).resolve().parents[3]
sys.path[:0]=[str(ROOT/'tools/phase6'),str(ROOT/'compiler')]
import representation_screen as rs

result={'scope':__doc__,'source_sha256':rs.digest(Path(__file__)), 'models':{}}
rng=np.random.default_rng(61002)
for name in ('kws','vww','ad'):
    folder=rs.BASE/name
    report=json.loads((folder/'report.json').read_text())
    predictions=json.loads((folder/'predictions.json').read_text())['heldout']
    indices=np.array(report['selection']['heldout_indices'])
    archive=ROOT/('work/phase0-ad/features/ad.accuracy.npz' if name=='ad' else f'work/quality/{name}.accuracy.npz')
    labels=rs.member(archive,'recording_labels' if name=='ad' else 'labels',folder/'mapped')[indices]
    baseline=np.array(predictions['dense'])
    candidate=np.array(predictions['selected/int8'])
    if name=='ad':
        pos=np.flatnonzero(labels==1);neg=np.flatnonzero(labels==0)
        delta=[]
        for _ in range(2000):
            ii=np.concatenate((rng.choice(pos,len(pos)),rng.choice(neg,len(neg))))
            delta.append(rs.auc(labels[ii],candidate[ii])-rs.auc(labels[ii],baseline[ii]))
        point=rs.auc(labels,candidate)-rs.auc(labels,baseline)
    else:
        difference=(candidate==labels).astype(float)-(baseline==labels).astype(float)
        groups=[np.flatnonzero(labels==label) for label in np.unique(labels)]
        delta=[]
        for _ in range(2000):
            ii=np.concatenate([rng.choice(g,len(g)) for g in groups])
            delta.append(float(np.mean(difference[ii])))
        point=float(np.mean(difference))
    result['models'][name]={'candidate_minus_dense':point,
                            'paired_bootstrap_percentile95_interval':np.quantile(delta,[.025,.975]).tolist(),
                            'replicates':2000,'resampling':'within-label paired sampling; AD unit is entire recording',
                            'interpretation':'exploratory uncertainty; no heldout-driven ranking or statistical superiority claim'}
rs.save(rs.BASE/'uncertainty.json',result)
print(json.dumps(result,indent=2))
