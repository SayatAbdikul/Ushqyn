# Native drained-boundary pause/resume prototype

The isolated sequencer/host/decoder extension passes12 native runs and one expected no-restore failure. The selected arithmetic engine is unchanged. Production files and the FPGA image are unchanged.

A CRC-validated one-byte pause request is the only extra busy mutation. The sequencer pauses after a fully drainedWAIT and exposes the next command index. Program, scratchpad and other control writes remain protected while busy; three rejection checks pass for every interleaving. RealDMA preserves all computed live SRAM granules, then a realAD inference executes in a separate external namespace andVWW resumes. Artificial full-SRAM clobber tests pass with restoration; omission deliberately produces aVWW output mismatch.

| Two-job witness, no artificial clobber | Descriptor interruption | SplitVWW |
| --- | ---: | ---: |
| FixedRAM AD response | 375,495 cycles | 316,339 cycles |
| FixedRAM blocking | 77,059 cycles | 17,216 cycles |
| FixedRAM saved live bytes | 8,640 | 10,176 |
| StalledRAM AD response | 493,825 cycles | 391,670 cycles |
| Resident program plus checkpoint reserve | 23,808 B | 29,808 B |

At a353,303-cycle deadline, splitVWW meets the fixedRAM witness and descriptor interruption misses it. Both miss under stalledRAM. Uninterrupted controls preserve the exact source cycle totals. Splitting costs5.40% isolatedVWW service and more checkpoint traffic.

The harness transportsUART bytes in one cycle and dynamically installs temporary checkpoint programs. Its global response is not physical750-kbaud timing; a resident autonomous controller/physical cost analysis is still needed. This is one two-job arrival witness, not generalEDF, a minimum-state theorem, worst-case schedulability, a routed design or an architecture novelty claim.

```sh
.venv/bin/python3 tools/phase6/deadline_pause.py run
```

`report.json`, `native/`, `fixtures/*/identity.json` and `native-build/identity.json` pin the final prototype and outputs. `failure-before-decoder-extension.json` preserves the initial attempt's rejected busy request; the final decoder narrowly permits the pause byte and all final tests pass.
