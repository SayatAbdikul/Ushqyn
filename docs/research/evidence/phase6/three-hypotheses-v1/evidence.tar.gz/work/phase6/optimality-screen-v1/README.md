# Bounded compiler optimality screen — 2026-10-01

The experiment completed. It found little additional scheduling opportunity
against the stronger controls in its declared families. It does not establish
optimality of the whole compiler, the selected physical schedule, or FPGA
architectures in general.

## Restricted strip-family experiment

The finite family consists of every partition of a fixed linear Conv + Relu
chain into consecutive regions and every integer full-width strip height from
1 to the region's output height. Region boundaries materialize INT8 values in
external memory. Every original Conv quantizer and activation quantizer remains
explicit. There is no overlap, channel tiling, retained halo cache, cross-region
retention, recomputation alternative, or arbitrary rectangle tiling.

The model checks disjoint padded input/output buffer occupancy, descriptor/LUT
staging, and eight output rows of weight/parameter staging, at 8, 16 and 32 KiB.
Its service objective adds eight-MAC slots, quantization elements and all
modeled serialized accesses to the shared 64-bit scratchpad port, including DMA.
**Intra-Conv operand reuse is idealized: requested inputs are read once.** This
is an analytical kernel model. Neither its costs nor its bounds are device
cycles, and its strips have not been lowered into the production DMA ABI.
Alignment/scatter packing and kernel control remain implementation obligations.

The independent checker enumerates scalar stencil dependencies to reconstruct
each strip's ancestors, work, port accesses and transient bytes. It does not
call the candidate geometry or cost functions. Every complete path is then
enumerated without pruning. A Bellman potential certificate is separately
checked against **every member** of the finite catalogue; telescoping its edge
inequalities lower-bounds all paths. The winning feasible path attains that
bound. A second, looser bound independently minimizes per-macro required work,
relaxing memory, compatibility and external activation transfers.

All 1,206 choices in the 18 case/budget families passed independent checks.
All 47,212 complete feasible paths were enumerated. The independent optima and
certificates agreed in every family. Winners passed exact integer-oracle
comparisons on the fixture and a seeded INT8 stress input: 46 region replays.
Corrupted quantizer identities, memory sizes, port counts, lower bounds, and
omitted catalogue members were rejected in all 18 families (90 rejections).

The strong proxy control chooses the cheapest legal tile height within each
fixed pair of macros, falling back to one macro only if the pair cannot fit.
It is explicitly **not** the production compiler. Its maximum cost gap to the
family optimum is 1.9833%, equivalent to at most 1.9447% cost reduction.

| Real fragment | SRAM | Model optimum | Strong fixed-pair cost gap | Selected region heights |
| --- | ---: | ---: | ---: | --- |
| KWS layers 3:9 | 8 KiB | 153,876 | 0% | 0:2 h9, 2:3 h9 |
| KWS layers 3:9 | 16 KiB | 151,144 | 0% | 0:2 h14, 2:3 h14 |
| KWS layers 3:9 | 32 KiB | 146,364 | 1.3993% | 0:3 h25 |
| VWW layers 15:21 | 8 KiB | 125,168 | 0% | 0:2 h3, 2:3 h3 |
| VWW layers 15:21 | 16 KiB | 120,664 | 0% | 0:2 h6, 2:3 h6 |
| VWW layers 15:21 | 32 KiB | 116,172 | 1.9833% | 0:3 h12 |
| VWW layers 23:31 | 8 KiB | 180,576 | 0% | 0:2 h3, 2:4 h3 |
| VWW layers 23:31 | 16 KiB | 169,776 | 0.7539% | 0:4 h6 |
| VWW layers 23:31 | 32 KiB | 169,776 | 0.7539% | 0:4 h6 |

The memory sweep changes legal geometry and recomputation cost. At 32 KiB, the
whole fragment can be retained; the remaining gap is boundary DMA rather than
a substantial compute saving. At 8/16 KiB, recomputing producer halos can offset
the benefit of extending a fused region, and the fixed-pair control is often
already optimal. The three synthetic cases independently cover three/four
macros and stride-two dependence.

The looser per-macro work bound has optimum/bound ratios of 1.0107–1.0307 on the
three real 32 KiB fragments; the worst ratio at 8 KiB is 1.1105. Its extra slack
comes from memory-induced repetitions and omitted external activation traffic.
These ratios concern the declared model only.

## Executable production-heuristic audit

Two original quantized fragments were also compiled with the existing v2
compiler: KWS layers 3:7 and VWW layers 15:19. For each fragment, all 64 serial
full32/prefer16 channel-tiling and optional producer/activation-retention
configurations were evaluated. Serial execution prohibits engine/DMA overlap
and therefore avoids shared-port contention assumptions in this comparison.

The existing coordinate-search strategy restricted to this identical serial
family reaches its exhaustive optimum in both cases: **0% heuristic gap**.
The winning bytecode passed the existing independent descriptor/provenance and
integer-oracle replay. Event costs are 789,183 KWS and 516,847 VWW. These remain
predictor scores, not measured board latency.

The actual `optimize_resident` result is also recorded, including its overlap
candidates: 787,071 KWS and 513,466 VWW. That broader result is **not certified
optimal** by this serial-family enumeration. These fragments are original-model
compiler probes, not comparisons against the newest constant-compacted,
three-pair physical schedule.

## Decision

The certifying method works and produces independently checkable finite-family
results, but this screen does not reveal a large mapping deficiency against
the stronger controls. It therefore does not justify an expensive new RTL
campaign or a stand-alone novelty claim. Generic optimal mapping/pruning is
already prior art; the result is useful as a bounded stopping certificate and
as a diagnostic method for future architectures.

## Reproduction

```sh
.venv/bin/python3 tools/phase6/optimality_screen.py
.venv/bin/python3 tools/phase6/optimality_screen.py --check work/phase6/optimality-screen-v1/kws_layers_3_9-32768-catalogue.json
```

`--check` consumes saved evidence and invokes neither candidate generation nor
dynamic programming. `report.json` contains source/model hashes, all results,
negative checks, replay evidence, runtime and peak RAM. Complete catalogue
records are saved separately for all 18 families. The complete run takes about
6 seconds and about 76 MiB peak RAM on this host; a 1 GiB guard is enforced.
No production files, hardware images, devices or dependencies were changed.
