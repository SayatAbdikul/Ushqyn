# Frozen factor models on the selected native engine

All32 full-model native runs passed, using the unchanged selected co-issue engine. VWW andAD dense/factor programs each run pinned real and seededINT8-stress inputs, fixed/stalled external RAM, and separate diagnostic/timed programs. Diagnostic runs check every materialized layer against the independent oracle; timed runs omit snapshotDMA. Program/data/external image capacities and source/fixture/executable hashes are checked.

| Generic native compiler, timed | Dense fixedRAM | Factor fixedRAM | Cycle reduction | StalledRAM reduction |
| --- | ---: | ---: | ---: | ---: |
| VWW | 4,347,606 | 3,029,706 | 30.3132% | 29.8821% |
| AD | 294,419 | 252,084 | 14.3792% | 14.3209% |

The VWW dense/factor comparison is matched generic compilation, not our strongest tuned schedule. The existing selectedB3 native control takes2,014,205 cycles, already below the generic factor program. Changed-model constant compaction/strip tuning is unresolved. These results demonstrate a decomposition effect under one compiler policy, not improvement over the best physical accelerator. AD remains below the15% internal latency investment gate.

The factors change the model's arithmetic. Native correctness means equality to each changed program's independent oracle, not equality to the original dense model. Quality is evaluated separately. RAM is a fixed/stalled abstract port andUART is virtual; no new board latency, energy, route or resource result is claimed. Hardware arithmetic sources are unchanged.

```sh
.venv/bin/python3 tools/phase6/representation_native.py
```

`report.json` records all32 runs, exact tensor checks, geometry, data transfers, memory limits and paired reductions. `fixtures/` and `native/` contain the independent expected values and raw native records/traces. The source-compatible trace executable is reused from the deadline screen.
