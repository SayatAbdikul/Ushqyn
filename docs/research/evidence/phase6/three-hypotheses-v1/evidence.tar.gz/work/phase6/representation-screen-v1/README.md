# Bounded representation / datapath screen — 2026-10-01

The experiment found executable low-rank opportunities in VWW and AD. It did
not establish an architectural novelty or FPGA speedup. Ordinary INT8 latent
factors provide the strongest arithmetic result; retaining wide latents costs
extra products on the existing eight INT8 lanes and offers little observed
quality benefit. Ordinary blocked fusion can eliminate the same latent spill.

| Workload | Development / heldout | Dense quality | INT8 factor quality | Charged INT8 product reduction | Weight payload saved | Decision |
|---|---:|---:|---:|---:|---:|---|
| KWS | 48 / 256 stratified samples | 236/256 = 92.1875% | 234/256 = 91.40625% | 4.21565% | 896 B | Fails 15% arithmetic investment gate |
| VWW | 48 / 256 stratified samples | 219/256 = 85.546875% | 221/256 = 86.328125% | 40.77555% | 155,008 B | Advance as a model/compression and executable geometry candidate |
| AD | 48 / 200 entire recordings | AUC 0.877668309 | AUC 0.888854680 | 16.95736% | 44,800 B | Advance INT8 factors; wide latents are unattractive |

Classification accuracy refers to these roughly label-balanced stratified
subsets. It does not estimate the original benchmark's natural label mixture
without reweighting. VWW's archive is a local validation partition, not an
official MLPerf-certified accuracy campaign. AD heldout covers all 39,200
windows of its 200 recordings; development covers the other 9,408 windows.
Previously declared calibration/evaluation archives were not modified.

All configurations were selected using spectra and development quality.
`selection-frozen-before-heldout.json` fixes rank and method before heldout
evaluation. A teacher fit used development activations only, with at most 32
spatial positions per sample and ridge coefficient 1e-6. This is closed-form
activation-weighted reduced-rank regression, not end-to-end fine-tuning or QAT.
There were no downloads or new dependencies.

The selected KWS policy factors layer 17 at rank 25. VWW selected activation
regression with ranks 37/19/11/8/5/7/4 on original layers 29/33/37/41/45/49/53.
AD selected ordinary SVD with ranks 76 and 79 on its first and final Gemm.
The driver records both INT8-code and dequantized-weight spectra; energy
retention is used for constructing candidates, never as an accuracy guarantee.

The numerical specification uses INT8 factor weights, symmetric latent codes,
explicit ties-away power-of-two rounding and saturation, and INT32 accumulation
with analytical all-input bounds. The accelerated dense reference matches the
independent integer oracle at every layer on two real development inputs per
workload. Exported INT8 factor programs also match the independent oracle on
two inputs. `selected-int8.uq2` is a valid software-v2 executable program; it
does not imply hardware execution. The production compiler and engine are
unchanged.

Controls were evaluated at matched local weight budgets:

| Workload | Column mask | Same columns + development teacher regression | INT8 factors |
|---|---:|---:|---:|
| KWS | 239/256 | 234/256 | 234/256 |
| VWW | 221/256 | 216/256 | 221/256 |
| AD pooled AUC | 0.647885878 | 0.826867816 | 0.888854680 |

The mask picks input columns by activation-weighted weight importance. The
refit solves a ridge least-squares teacher problem on exactly those columns,
then requantizes weights and biases with the production quantizer. This is a
stronger local control than a mask alone, but does not exhaust pruning,
propagated channel compaction, pruning retraining or distillation. Its reported
sparse operation and byte costs assume a gather or propagated channel-removal
implementation. The saved `.uq2` retains zero columns and is used to validate
quality and overflow; the current native engine would still execute those
zeros. VWW factors therefore have no demonstrated advantage over the original
mask in quality/arithmetic proxies. AD factors beat both tested controls.

Wide-latent costs explicitly charge only the second factor at two or three
INT8 limbs per product. Extra signed-limb correction, recombination, controller
cost, memory tiling, and physical area are excluded, so this remains an
optimistic operation model. VWW INT16 obtains 223/256 correct at 35.51518%
charged product reduction, and INT24 obtains 222/256 at 30.25482%. AD INT16
obtains AUC 0.890086207 but increases charged products by 5.86240%. Its INT24
implementation is rejected because the analytical INT32 accumulation bound
fails; wider accumulators were not implemented. KWS widths have identical
predictions and no material opportunity.

For exactly the same INT8 factors and latent rounding, separate factor calls
and a fused factor pair have identical outputs. Their logical latent write/read
traffic differs by 6,250 B in KWS, 5,958 B in VWW, and 310 B per AD window.
An ordinary blocked factor-pair fusion can remove this same traffic, so no
unique fused-latent mechanism is established. These bytes are logical
scratchpad transfers, not measured SDRAM traffic. Layer records include local
latent storage, factor weights, minimum live footprints, and eight-spatial-lane
padding. Footprints that exceed 32 KiB require weight/reduction tiling before
any cycle claim.

Paired exploratory bootstrap intervals expose the uncertainty of the quality
screen (`uncertainty.json`, 2,000 within-label resamples; AD unit is the entire
recording). Candidate-minus-dense 95% intervals are KWS [-1.9531, 0] percentage
points, VWW [-1.5625, +3.125] percentage points, and AD AUC [-0.01540, +0.03654].
They establish neither superiority nor a formal one-percentage-point/.01-AUC
noninferiority result. New untouched evaluation is required for a paper claim.

Archives are decompressed once through a 1 MiB streaming buffer into `.npy`
files, then memory-mapped. The VWW feature map is 1.21 GB on disk; it is never
loaded as one RAM array. All processes use one numerical thread. Recorded VWW
factor process RSS was 143,687,680 B (~137 MiB); the all-model refit process
peaked at 230,735,872 B (~220 MiB). The aggregate factor report's RSS field
belongs to its last resumed KWS process (94,617,600 B), not a campaign-wide
upper bound. No multi-gigabyte retained-array behavior occurred.

Reproduction:

```sh
.venv/bin/python3 tools/phase6/representation_screen.py --class-dev 48 --class-heldout 256 --ad-dev 48
.venv/bin/python3 work/phase6/representation-screen-v1/pruning_refit.py
.venv/bin/python3 work/phase6/representation-screen-v1/uncertainty.py
```

The final factor report merges resumed per-model runs and pins each driver's
version in its exported program. VWW was completed before the driver learned
to record a rejected AD wide candidate rather than abort. Those changes affect
resume/error reporting, not VWW factor numerics. Its export remains frozen at
SHA256 `f8057045191dadb101463ccaec4cc3ac07247d991c53c9f6a66253da7dbbbbf4`.

The next gates are: executable compiler/native comparison against original
dense programs with exactly matched input/protocol; frozen full/untouched
quality evaluation; a stronger globally propagated pruning/QAT control;
physical timing/resource and board/energy checks if a mechanism survives.
To claim architectural novelty, a factor implementation must beat ordinary
factor execution and blocked fusion for a reason beyond standard decomposition.
The current evidence supports a promising compression experiment, especially
AD, and rejects assuming that wide latents are free on an INT8 engine.
