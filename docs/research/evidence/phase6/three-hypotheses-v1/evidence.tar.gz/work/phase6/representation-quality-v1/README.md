# Expanded frozen-candidate quality evaluation

All 4,586 KWS and 10,657 VWW examples excluded from the preceding 48-example development and 256-example exploratory screens were evaluated. No candidate selection changed.

| Model | Dense | INT8 factor | Frozen column mask | Dev-only pruning refit |
| --- | ---: | ---: | ---: | ---: |
| KWS | 4235/4586 | 4242/4586 | 4233/4586 | 4250/4586 |
| VWW | 8976/10657 | 8955/10657 | 8833/10657 | 8815/10657 |

The full per-example predictions, labels and exclusion indices are saved in each model's `report.json` and `mask-report.json`. The frozen mask exactly reproduces all earlier256 predictions. Paired bootstrap intervals use original untouched label proportions. VWW factor accuracy loss is0.1971pp; factor-minus-dense95% interval is[-0.5067,+0.0938]pp. Its factor-minus-mask interval is[+0.6662,+1.6046]pp. This is a redesigned research protocol, not an official benchmark accuracy certification. VWW's local archive is not the official certified MLPerf accuracy split.

Integer convolution is accelerated using CPU float64 under an absolute partial-sum bound below2^53; requantization remainsINT64, ties-away, with actualINT32 overflow checks. Every layer is independently oracle-checked on real inputs, seededINT8 stress and bothINT8 endpoint values before bulk evaluation. Dense/factor/refit checks are in `report.json`; mask checks are in `mask-report.json`. The source archives and mappedNPY member bytes are verified. No feature array is loaded in full as a heap allocation.

The highest final process RSS is790.7MiB. The mask evaluator periodically closes/reopens the feature mapping to bound resident file pages and peaks at263.0MiB. This fixed and replaced a first mask run with1.24GiB mapped-file RSS. Final runs enforce a1GiB guard; arithmetic and predictions are unchanged.

```sh
.venv/bin/python3 tools/phase6/representation_quality.py
.venv/bin/python3 tools/phase6/representation_mask_control.py
```

The zero-column mask/refit executables validate quality only. Sparse cost savings additionally need gather or channel compaction. No FPGA speed, architecture novelty, end-to-end QAT or globally retrained pruning claim follows from these results.
