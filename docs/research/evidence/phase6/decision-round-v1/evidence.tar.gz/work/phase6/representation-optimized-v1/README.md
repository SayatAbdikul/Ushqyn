# Frozen VWW factors against optimized dense execution

The completed matched comparison finds a 0.2108% fixed-RAM cycle reduction and 0.2039% reduction for one sampled stalled RAM seed. Dense takes 2,014,205 / 2,059,395 cycles; the frozen factor graph takes 2,009,959 / 2,055,195. This candidate does not support a central architecture claim.

Both graphs receive the same exact channel grouping, constant folding and compaction, and the same 12 final-region geometry/cache/residency settings within the incumbent four-region path. Three settings per graph fit; nine fail explicit capacity constraints. This is a bounded compiler comparison, not exhaustive schedule optimality. Dense reproduces the strongest B3 command and payload binaries byte for byte.

After these transformations, useful MACs are 3,733,073 dense and 3,707,612 factor: only 0.6820% fewer. Factor execution needs 49 engine RUNs versus 42, 16,464 program bytes versus 15,568, and 213,334 scheduled DMA bytes versus 212,558. The earlier large logical reduction was measured before this stronger dense optimization.

Six feasible candidate timing runs, 16 selected native runs and two identity-LUT ablation runs pass. Selected validation covers a pinned real input and a distinct full-range INT8 stress input, fixed and sampled stalled RAM, and timed and per-descriptor diagnostic streams. Diagnostic streams check all 42 dense or 49 factor RUN outputs plus the final output. Frozen factor arithmetic is preserved; signed latent identity clips are proved and their LUT tags and unused DMA are removed. No arithmetic RTL changes or new held-out accuracy evaluation occur.

report.json contains cycle decomposition, selection, capacity failures and source/input hashes. sources/reference contains the imported compiler dependencies, including the lazy generated-lowering dependency. A separate bundled-compiler probe regenerates both selected command/payload binaries exactly; its result is in ../decision-round-v1/bundled-compiler-regeneration.json. Original benchmark inputs remain in the authorized project dataset locations. Native RTL and the dense control are bundled separately. Build products and the native executable are not portable evidence.

Run with `.venv/bin/python3 tools/phase6/representation_optimized.py`. To use the bundled compiler, set `PHASE6_SPATIAL_COMPILER_ROOT` to the absolute path of sources/reference. The driver limits numeric threads to one and Python RSS to 1 GiB. Board SDRAM timing and energy are not measured. Prior frozen accuracy evidence is retained without model retuning.
