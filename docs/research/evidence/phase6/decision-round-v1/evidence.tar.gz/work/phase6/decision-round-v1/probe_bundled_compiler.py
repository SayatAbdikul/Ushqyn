"""Regenerate both winners from bundled compiler sources, without native reruns."""
import os
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[3]
os.environ['PHASE6_SPATIAL_COMPILER_ROOT'] = str(ROOT/'work/phase6/representation-optimized-v1/sources/reference')
sys.path.insert(0,str(ROOT/'tools/phase6'))
import representation_optimized as experiment
import json
import resource

original,pinned,dense,dense_maps,dense_provenance=experiment.matched_model('vww')
frozen=experiment.load_image((ROOT/'work/phase6/representation-screen-v1/vww/selected-int8.uq2').read_bytes())
factor,factor_maps,factor_provenance=experiment.factor_model(frozen)
report=experiment.json.loads((experiment.OUT/'report.json').read_text())
result={'status':'passed-bundled-compiler-regeneration','compiler_root':str(experiment.REFERENCE),'variants':{}}
for name,program,orig,maps,provenance in (
    ('dense',dense,original,dense_maps,dense_provenance),('factor',factor,frozen,factor_maps,factor_provenance)):
    row=report['variants'][name]
    selected=next(c for c in row['candidates'] if c['index']==row['selected_index'])
    oracle=experiment.verified_oracle(orig,program,maps,pinned,provenance)
    code,payload,schedule=experiment.compose(program,selected['configurations'],oracle,
        ROOT/'work/phase6/decision-round-v1/bundled-regeneration'/name)
    fixture=ROOT/selected['fixture']
    if code!=(fixture/'commands.bin').read_bytes() or payload!=(fixture/'payload.bin').read_bytes():
        raise ValueError('bundled compiler regeneration differs: '+name)
    result['variants'][name]={'commands_sha256':experiment.sha(fixture/'commands.bin'),
                             'payload_sha256':experiment.sha(fixture/'payload.bin')}
result['peak_python_rss_bytes']=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
experiment.save(ROOT/'work/phase6/decision-round-v1/bundled-compiler-regeneration.json',result)
print(json.dumps(result,indent=2))
