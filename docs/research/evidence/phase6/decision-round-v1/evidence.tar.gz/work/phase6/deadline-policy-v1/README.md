# Budgeted resident interruption policy

All policies receive the same resident context assumptions and conservative saving of live SRAM granules. The 828 arrival cases and their deadlines were frozen before candidate evaluation. The dynamic program minimizes a maximum blocking plus save-cost surrogate under the actual 32 KiB program and metadata capacity, without consulting scheduling outcomes. Its optimality is limited to this finite catalogue.

The new selectively split programs pass exact native output checks in fixed RAM and one sampled stalled RAM mode. VWW takes 2,026,760 fixed-RAM cycles versus 2,014,205 for the original; KWS takes 1,120,565 versus 1,099,170. AD has no eligible long RUN and reuses an identical original program.

The scheduling model covers all six ordered task pairs with one suspended background job and nonpreemptive urgent jobs. It evaluates 52,992 schedules: four variants across 828 cases, two native memory traces, four DMA word costs and two dispatch-cost allowances. These correlated cases are a sensitivity study, not deployment frequencies.

| Stream | Zero-miss rescues over original | Cases with more misses than original |
|---|---:|---:|
| Uniform 25k | 996 | 155 |
| Uniform 50k | 835 | 128 |
| Selective long 25k | 729 | 121 |

Against uniform 25k, the selective stream has fewer misses in 183 cases and more in 473; against uniform 50k, it has fewer in 161 and more in 325. The tested selective rule therefore does not establish an overall scheduling advantage over the strong controls. It uses less resident storage in the VWW/AD pair: 26,896 bytes versus 32,720 for uniform 25k and 30,816 for uniform 50k. The original uses 21,872. All capacities include both model programs, sparse precompiled save/restore programs, metadata and a 32-byte stress-only clobber prefix. Artificial clobber latency is excluded from the scheduling model.

Unrestricted precompiled checkpoints at every drained boundary exceed 32 KiB for all three-job variants (133,840 to 238,832 bytes). Raw model programs fit, but a budgeted three-job controller and joint allocation were not evaluated.

See protocol.json, selection-identity.json, plans.json, native-evidence.json, results.json and report.json. The independent audit checks serialized metadata and checkpoint programs, an exhaustive small dynamic-program oracle, and deadline/response/service summaries reconstructed from every raw job completion record.

The original scheduling results use isolated native traces and explicit transport costs; their lookup overhead is superseded by the finer replay below. Neither model provides a worst-case memory bound or establishes physical deadlines. The resident controller experiment supplies separate interleaving and implementation evidence. ART and DERCA already cover preemption point placement and state/dataflow choices; architectural novelty remains unestablished.

A follow-up fine-grained replay preserves every drained WAIT and charges five cycles per metadata header/record only while a request is pending, including full unsuccessful table scans. It preserves the same frozen candidates and 828 arrival cases. Matching scans conservatively overcharge net branching by one cycle. See scan-calibrated-report.json and scan-calibrated-results.json. DMA and fixed dispatch remain explicit sensitivity costs; this adds the actual lookup mechanism without claiming native validation of all schedules.

```json
{
  "baseline": {
    "cases": 13248,
    "selective_fewer_misses": 967,
    "selective_more_misses": 121,
    "same_misses": 12160,
    "selective_zero_miss_rescues": 732,
    "control_zero_miss_rescues": 91
  },
  "split25000": {
    "cases": 13248,
    "selective_fewer_misses": 199,
    "selective_more_misses": 461,
    "same_misses": 12588,
    "selective_zero_miss_rescues": 141,
    "control_zero_miss_rescues": 349
  },
  "split50000": {
    "cases": 13248,
    "selective_fewer_misses": 167,
    "selective_more_misses": 321,
    "same_misses": 12760,
    "selective_zero_miss_rescues": 111,
    "control_zero_miss_rescues": 205
  }
}
```

The finer replay gives selective fewer/more misses in 199/461 cases versus uniform 25k, and 167/321 versus uniform 50k. Selective has 732 zero-miss rescues over the original, but still does not dominate either uniform control. Lookup timing matches all eight separately preserved native normal-urgent witness counters. These observations qualify the model; they do not constitute native execution of the entire arrival grid.

The simulator maintains an EDF queue of urgent arrivals. The tested RTL admits one outstanding urgent request and rejects notifications during save/urgent/restore. A queue/admission adapter, its resource cost and admission delay are unimplemented. Periodic and burst trace outcomes therefore apply to the declared scheduling model, not directly to the current RTL. Repeated jobs use immutable inputs rather than fresh input transport. Physical controller placement also failed in the matched experiment. These limits prevent a hardware schedulability claim.
