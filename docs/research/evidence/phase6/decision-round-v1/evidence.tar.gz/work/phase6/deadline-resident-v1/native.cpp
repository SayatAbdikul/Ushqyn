// Full command-sequencer/engine/SRAM/DMA simulation with a stalled RAM port.
// External RAM is a test model, not the electrical SDRAM controller.
#include "Vv2_tiled_host_bridge.h"
#include "Vv2_tiled_host_bridge___024root.h"
#include "verilated.h"
#include <algorithm>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <iterator>
#include <random>
#include <map>
#include <stdexcept>
#include <string>
#include <vector>
using Bytes=std::vector<uint8_t>;
static Vv2_tiled_host_bridge d;
static Bytes memory(8*1024*1024);
static std::mt19937 rng;
static bool stalls=false,pending=false,held=false;
static unsigned delay=0,sequence_id=0;
static uint64_t pending_data=0,cycles=0;
struct Request { uint32_t addr; uint64_t data; unsigned wr,mask; };
static Request hold;
static void require(bool b,const std::string& s){if(!b)throw std::runtime_error(s);}
static Bytes file(const std::string& s){std::ifstream f(s,std::ios::binary);require(bool(f),"missing "+s);return Bytes(std::istreambuf_iterator<char>(f),{});}
static uint32_t u32(const Bytes& b,unsigned i){return uint32_t(b.at(i))|uint32_t(b.at(i+1))<<8|uint32_t(b.at(i+2))<<16|uint32_t(b.at(i+3))<<24;}
static uint16_t crc(const Bytes& b,unsigned first,unsigned end){uint16_t c=65535;for(unsigned i=first;i<end;i++){c^=uint16_t(b[i])<<8;for(int k=0;k<8;k++)c=c&0x8000?(c<<1)^0x1021:c<<1;}return c;}
static void observe_context();
static int step(){
    d.clk=0; bool ready=!pending&&(!stalls||rng()%5!=0);
    d.ext_ready=ready;d.ext_rvalid=0;
    if(pending){if(delay==0){d.ext_rvalid=1;d.ext_rdata=pending_data;pending=false;}else delay--;}
    d.eval();int out=d.tx_valid&&d.tx_ready?d.tx_data:-1;
    Request r{d.ext_addr,d.ext_wdata,d.ext_wr,d.ext_wstrb};
    if(held)require(d.ext_req&&r.addr==hold.addr&&r.data==hold.data&&r.wr==hold.wr&&r.mask==hold.mask,"unstable external request");
    held=d.ext_req&&!ready;if(held)hold=r;
    if(d.ext_req&&ready){
        require(r.addr%8==0&&r.addr+8<=memory.size(),"external range/alignment");
        if(r.wr){for(unsigned k=0;k<8;k++)if(r.mask>>k&1)memory[r.addr+k]=r.data>>(k*8);}
        else{require(!pending,"overlapping RAM reads");pending=true;delay=stalls?rng()%5:0;pending_data=0;for(unsigned k=0;k<8;k++)pending_data|=uint64_t(memory[r.addr+k])<<(k*8);}
    }
    d.clk=1;d.eval();cycles++;observe_context();return out;
}
static Bytes command(unsigned cmd,uint32_t addr=0,const Bytes& data={},unsigned length=0){
    if(cmd==3)length=data.size();unsigned seq=sequence_id++&255;
    Bytes b={0xa5,0x5a,2,uint8_t(cmd),uint8_t(seq),uint8_t(addr),uint8_t(addr>>8),uint8_t(addr>>16),uint8_t(length),uint8_t(length>>8)};
    b.insert(b.end(),data.begin(),data.end());auto c=crc(b,2,b.size());b.push_back(c);b.push_back(c>>8);
    d.tx_ready=0;d.rx_valid=1;for(auto byte:b){d.rx_data=byte;step();}d.rx_valid=0;d.tx_ready=1;
    Bytes reply;unsigned total=0;
    for(unsigned n=0;n<100000;n++){int byte=step();if(byte>=0)reply.push_back(byte);if(reply.size()==10)total=12+reply[8]+(unsigned(reply[9])<<8);if(total&&reply.size()==total)break;}
    require(total&&reply.size()==total,"protocol timeout");
    require(reply[0]==0xa5&&reply[1]==0x5a&&reply[2]==2&&reply[3]==(cmd|128)&&reply[4]==seq,"reply header");
    require(crc(reply,2,reply.size()-2)==(unsigned(reply[reply.size()-2])|(unsigned(reply.back())<<8)),"reply CRC");
    require(reply[10]==0,"command rejected "+std::to_string(reply[10]));
    return Bytes(reply.begin()+11,reply.end()-2);
}

static Bytes sram_snapshot(){
    Bytes out(32768);auto* r=d.rootp;
    for(unsigned i=0;i<4096;i++){
                out[i*8+0]=r->v2_tiled_host_bridge__DOT__core__DOT__memory__DOT__banks__BRA__0__KET____DOT__ram[i];
        out[i*8+1]=r->v2_tiled_host_bridge__DOT__core__DOT__memory__DOT__banks__BRA__1__KET____DOT__ram[i];
        out[i*8+2]=r->v2_tiled_host_bridge__DOT__core__DOT__memory__DOT__banks__BRA__2__KET____DOT__ram[i];
        out[i*8+3]=r->v2_tiled_host_bridge__DOT__core__DOT__memory__DOT__banks__BRA__3__KET____DOT__ram[i];
        out[i*8+4]=r->v2_tiled_host_bridge__DOT__core__DOT__memory__DOT__banks__BRA__4__KET____DOT__ram[i];
        out[i*8+5]=r->v2_tiled_host_bridge__DOT__core__DOT__memory__DOT__banks__BRA__5__KET____DOT__ram[i];
        out[i*8+6]=r->v2_tiled_host_bridge__DOT__core__DOT__memory__DOT__banks__BRA__6__KET____DOT__ram[i];
        out[i*8+7]=r->v2_tiled_host_bridge__DOT__core__DOT__memory__DOT__banks__BRA__7__KET____DOT__ram[i];
    }
    return out;
}
static unsigned prior_phase=0,uart_after_accept=0,resume_pc=0,contextbase=0,urgententry=0,clobberdonepc=0;
static uint64_t accepted_cycle=0,checkpoint_cycle=0,urgent_done_cycle=0,restore_done_cycle=0;
static bool active_service=false,clobber_checked=false,want_clobber=true,completion_fallback=false;
static unsigned metadata_cycles=0;
static Bytes before;
static std::map<unsigned,std::vector<std::pair<unsigned,unsigned>>> live;
static unsigned saved_bytes=0,restored_mismatches=0,context_mismatches=0;
static void observe_context(){
    auto* r=d.rootp;unsigned phase=r->v2_tiled_host_bridge__DOT__seq_context_phase;
    if(!accepted_cycle&&r->v2_tiled_host_bridge__DOT__seq_urgent_pending){accepted_cycle=cycles;active_service=true;}
    if(active_service&&d.rx_valid)uart_after_accept++;
    unsigned state=r->v2_tiled_host_bridge__DOT__sequencer__DOT__state;
    if(state>=8&&state<=12)metadata_cycles++;
    if(prior_phase==0&&phase==1){
        require(!d.engine_busy&&!d.dma_busy&&!r->v2_tiled_host_bridge__DOT__dma_pending&&!pending,"checkpoint was not drained");
        checkpoint_cycle=cycles;resume_pc=r->v2_tiled_host_bridge__DOT__seq_resume_index;
        require(live.count(resume_pc),"undeclared checkpoint PC");before=sram_snapshot();
        for(auto [base,length]:live[resume_pc])saved_bytes+=length;
    }
    if(prior_phase==1&&phase==2){
        for(auto [base,length]:live[resume_pc])for(unsigned i=base;i<base+length;i++)context_mismatches+=before[i]!=memory[contextbase+i];
        require(context_mismatches==0,"resident save DMA changed live bytes");
    }
    if(want_clobber&&phase==2&&!clobber_checked&&r->v2_tiled_host_bridge__DOT__seq_index==clobberdonepc){
        auto s=sram_snapshot();require(std::all_of(s.begin(),s.end(),[](auto v){return v==0xa5;}),"full SRAM destructive DMA clobber missing");
        clobber_checked=true;
    }
    if(prior_phase==2&&phase==3)urgent_done_cycle=cycles;
    if(prior_phase==0&&phase==2)completion_fallback=true;
    if(prior_phase==2&&phase==0)urgent_done_cycle=cycles;
    if(prior_phase==3&&phase==0){
        restore_done_cycle=cycles;auto after=sram_snapshot();
        for(auto [base,length]:live[resume_pc])for(unsigned i=base;i<base+length;i++)restored_mismatches+=before[i]!=after[i];
    }
    prior_phase=phase;
}
int main(int argc,char** argv){try{
    Verilated::commandArgs(argc,argv);require(argc==5||argc==6,"fixture,seed,report,mode[,release] required");
    std::string dir=argv[1];unsigned seed=std::stoul(argv[2]),mode=std::stoul(argv[4]);
    want_clobber=mode!=0;
    stalls=seed!=0;rng.seed(seed);
    auto payload=file(dir+"/payload.bin"),program=file(dir+"/commands.bin");
    require(payload.size()<=memory.size()&&program.size()<=32768,"resident memory capacity");
    std::copy(payload.begin(),payload.end(),memory.begin());
    unsigned entry,metadataindex,release,deadline;
    std::ifstream cf(dir+"/control.txt");cf>>entry>>metadataindex>>urgententry>>contextbase>>clobberdonepc>>release>>deadline;
    require(bool(cf),"invalid resident control metadata");
    if(argc==6)release=std::stoul(argv[5]);
    std::ifstream lf(dir+"/live.txt");unsigned pc,n;
    while(lf>>pc>>n){auto& spans=live[pc];for(unsigned i=0;i<n;i++){unsigned b,c;lf>>b>>c;spans.emplace_back(b,c);}}
    require(!live.empty(),"resident checkpoint metadata empty");
    if(mode==0){ // Same resident capacity, bypass artificial stress clobber only.
        for(unsigned k=0;k<4;k++)program[metadataindex*16+k]=clobberdonepc>>(k*8);
    }
    if(mode==2){ // Negative control: omit every restore DMA, preserving code capacity.
        unsigned count=u32(program,metadataindex*16+4);
        for(unsigned i=0;i<count;i++){
            unsigned restore=u32(program,(metadataindex+1+i)*16+8);
            std::fill(program.begin()+restore*16,program.begin()+restore*16+16,0);
        }
    }
    d.rst_n=0;d.rx_valid=0;d.tx_ready=0;d.memory_initialized=1;d.memory_port_busy=0;
    for(int k=0;k<4;k++)step();d.rst_n=1;for(int k=0;k<4;k++)step();
    for(unsigned i=0;i<program.size();i+=64)command(3,0x500000+i,Bytes(program.begin()+i,program.begin()+std::min(unsigned(program.size()),i+64)));
    command(3,0x41001c,{uint8_t(entry),uint8_t(entry>>8),uint8_t(metadataindex),uint8_t(metadataindex>>8)});
    uint64_t start=cycles;command(3,0x410000,{1});
    unsigned guard_checks=0;
    for(unsigned address:{0x500000u,0u,0x410000u,0x41001eu}){
        bool rejected=false;try{command(3,address,{0});}
        catch(const std::runtime_error& e){rejected=std::string(e.what())=="command rejected 3";}
        require(rejected,"unsafe busy write accepted");guard_checks++;
    }
    unsigned ticks=0;
    while(d.rootp->v2_tiled_host_bridge__DOT__seq_elapsed<release&&d.rootp->v2_tiled_host_bridge__DOT__seq_busy&&ticks++<20000000)step();
    require(ticks<20000000&&d.rootp->v2_tiled_host_bridge__DOT__seq_busy,"urgent release too late");
    uint64_t release_cycle=cycles;
    if(mode!=3)command(3,0x410000,{2});
    ticks=0;while(d.rootp->v2_tiled_host_bridge__DOT__seq_busy&&ticks++<20000000)step();
    require(ticks<20000000,"autonomous resident timeout");
    uint64_t completion=cycles;
    active_service=false;
    auto regs=command(2,0x410000,{},32);unsigned error=regs[1];
    unsigned mismatches=0,ad_mismatches=0,checks=0;
    std::ifstream checks_file(dir+"/checks.txt");unsigned address;std::string name;
    while(checks_file>>address>>name){
        if(mode==3&&name!="vww-output.bin")continue;
        auto expected=file(dir+"/"+name);unsigned local=0;
        for(unsigned i=0;i<expected.size();i++)local+=memory[address+i]!=expected[i];
        if(name=="ad-output.bin")ad_mismatches+=local;
        mismatches+=local;checks++;
    }
    require(uart_after_accept==0,"host UART was used after accepted urgent request");
    if(mode==3){require(error==0&&mismatches==0&&checks==1,"pause-disabled baseline mismatch");}
    else {
        require(accepted_cycle&&(checkpoint_cycle||completion_fallback)&&urgent_done_cycle&&(!want_clobber||clobber_checked),"resident phase coverage incomplete");
        require(ad_mismatches==0,"urgent AD output differs");
        if(mode==2)require(error||mismatches||restored_mismatches,"omitted restore negative failed to detect corruption");
        else require(error==0&&mismatches==0&&restored_mismatches==0&&checks==2,"resident exact output or restored context mismatch");
    }
    std::ofstream f(argv[3]);
    f<<"{\"status\":\"passed\",\"mode\":"<<mode<<",\"seed\":"<<seed<<",\"program_bytes\":"<<program.size()
     <<",\"busy_guard_checks\":"<<guard_checks<<",\"post_request_uart_rx_cycles\":"<<uart_after_accept
     <<",\"release_elapsed_target\":"<<release
     <<",\"release_cycle\":"<<release_cycle<<",\"accepted_cycle\":"<<accepted_cycle
     <<",\"checkpoint_cycle\":"<<checkpoint_cycle<<",\"urgent_done_cycle\":"<<urgent_done_cycle
     <<",\"restore_done_cycle\":"<<restore_done_cycle<<",\"response_cycles_from_accept\":"<<(urgent_done_cycle?urgent_done_cycle-accepted_cycle:0)
     <<",\"response_cycles_from_release\":"<<(urgent_done_cycle?urgent_done_cycle-release_cycle:0)
     <<",\"urgent_relative_deadline\":"<<deadline<<",\"urgent_deadline_missed\":"<<(urgent_done_cycle&&urgent_done_cycle-release_cycle>deadline?"true":"false")
     <<",\"vww_completion_cycles\":"<<completion-start<<",\"sequence_elapsed_cycles\":"<<u32(regs,8)
     <<",\"resume_pc\":"<<resume_pc<<",\"saved_live_bytes\":"<<saved_bytes
     <<",\"completion_fallback\":"<<(completion_fallback?"true":"false")
     <<",\"metadata_scan_cycles\":"<<metadata_cycles
     <<",\"save_context_mismatches\":"<<context_mismatches<<",\"restored_byte_mismatches\":"<<restored_mismatches
     <<",\"output_byte_mismatches\":"<<mismatches<<",\"sequence_error\":"<<error
     <<",\"tensor_checks\":"<<checks<<",\"clobber_checked\":"<<(clobber_checked?"true":"false")<<"}\n";
    d.final();return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<std::endl;return 1;}}
