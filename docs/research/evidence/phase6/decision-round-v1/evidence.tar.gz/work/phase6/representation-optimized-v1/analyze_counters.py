#!/usr/bin/env python3
"""Independent descriptor geometry and measured trace accounting audit."""
import hashlib,json,math,struct,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT/'compiler'))
from hardware_v2 import Descriptor
BASE=Path(__file__).resolve().parent
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
report=json.loads((BASE/'report.json').read_text())
answer={'scope':'descriptor arithmetic and padded lane slots are structural counts, not inferred cycles or energy',
        'driver_report_sha256':sha(BASE/'report.json'),'analysis_sha256':sha(Path(__file__)),'models':{}}
for name in ('dense','factor'):
    directory=BASE/'selected'/name/'pinned/timed'
    code=(directory/'commands.bin').read_bytes();ext=(directory/'payload.bin').read_bytes();sram=bytearray(32768)
    runs=[];regions=json.loads((directory/'schedule.json').read_text())['components']
    for index,row in enumerate(struct.iter_unpack('<BBHIII',code)):
        op,flags,_,a,b,c=row
        if op==1 and flags:sram[b:b+c]=ext[a:a+c]
        if op!=2:continue
        raw=bytearray(sram[a:a+64]);raw[6:8]=b'\0\0';d=Descriptor.decode(bytes(raw));d.validate()
        if d.output<128:raise ValueError('descriptor model requires no engine writes into descriptor region')
        if d.opcode not in (1,4,6):continue
        pixels=d.outputs//d.output_c if d.opcode!=1 else 1
        pw=d.opcode==4 and d.kernel_h==d.kernel_w==1 and d.stride_h==d.stride_w==1 and not any((d.pad_top,d.pad_bottom,d.pad_left,d.pad_right)) and d.count<=256
        slots=d.output_c*math.ceil(pixels/8)*8*d.count if pw else None
        runs.append({'command':index,'opcode':d.opcode,'outputs':d.outputs,'input_reduction':d.count,
            'output_channels':d.outputs if d.opcode==1 else d.output_c,'pixels_per_channel':pixels,
            'descriptor_macs':d.outputs*d.count,'spatial_pointwise':pw,'pointwise_mac_lane_slots':slots,
            'aligned_weight_bytes':(d.outputs if d.opcode==1 else d.output_c)*d.row_stride,
            'logical_weight_bytes':(d.outputs if d.opcode==1 else d.output_c)*d.count})
    trace=json.loads((BASE/'selected'/name/'pinned/timed-s0.json.trace.json').read_text())
    breakdown=[]
    for region in regions:
        a,b=trace[region['first_command']],trace[region['last_command']]
        breakdown.append({'start_layer':region['start'],'stop_layer':region['stop'],
            'elapsed_cycles':b['elapsed']-a['elapsed'],'engine_cycles':b['engine_cycles']-a['engine_cycles'],
            'dma_cycles':b['dma_cycles']-a['dma_cycles']})
    pointwise=[r for r in runs if r['spatial_pointwise']]
    useful=sum(r['descriptor_macs'] for r in pointwise);slots=sum(r['pointwise_mac_lane_slots'] for r in pointwise)
    answer['models'][name]={'descriptor_macs':sum(r['descriptor_macs'] for r in runs),
        'pointwise_descriptor_macs':useful,'pointwise_mac_lane_slots':slots,
        'pointwise_lane_utilization_fraction':useful/slots,
        'pointwise_3x3_pixels':[r for r in pointwise if r['pixels_per_channel']==9],
        'pointwise_6x6_pixels':[r for r in pointwise if r['pixels_per_channel']==36],
        'logical_weight_bytes':sum(r['logical_weight_bytes'] for r in runs),
        'aligned_weight_bytes':sum(r['aligned_weight_bytes'] for r in runs),
        'per_region_trace_breakdown':breakdown,'runs':runs}
    for sample in ('pinned','stress'):
        for mode in ('timed','check'):
            for seed in (0,6063):
                path=BASE/'selected'/name/sample/f'{mode}-s{seed}.json';r=json.loads(path.read_text())
                if r['status']!='passed':raise ValueError('native check failed')
                t=json.loads(Path(str(path)+'.trace.json').read_text())
                if t[-1]['elapsed']!=r['elapsed_cycles']:raise ValueError('trace total differs')
for source in report['source_bundle']:
    if sha(ROOT/source['bundled_path'])!=source['sha256']:raise ValueError('source bundle changed')
answer['status']='passed-independent-counter-and-source-bundle-audit'
(BASE/'counter-audit.json').write_text(json.dumps(answer,indent=2,sort_keys=True)+'\n')
print(json.dumps({n:{k:v[k] for k in ('descriptor_macs','pointwise_descriptor_macs','pointwise_mac_lane_slots','pointwise_lane_utilization_fraction','logical_weight_bytes','aligned_weight_bytes')} for n,v in answer['models'].items()},indent=2))
