def fold_final_constants(grouped):
    """Return folded graph and a certificate valid for all INT8 model inputs."""
    program=copy.deepcopy(grouped)
    conv,act,pool,reshape,gemm=(program.layers[i] for i in VWW)
    if ([x.op for x in (conv,act,pool,reshape,gemm)]!=
            ['Conv','Relu','AveragePool','Reshape','Gemm'] or
            any(program.layers[j].inputs!=[program.layers[j-1].output]
                for j in range(61,65))):
        raise ValueError('unsupported final VWW graph')
    if (conv.attributes.get('group',1)!=1 or
            program.tensors[conv.output].shape!=(1,256,3,3) or
            program.tensors[pool.output].shape!=(1,256,1,1) or
            program.tensors[reshape.output].shape!=(1,256) or
            program.tensors[gemm.output].shape!=(1,2)):
        raise ValueError('final VWW dimensions changed')
    attrs=pool.attributes
    if (attrs.get('kernel_shape')!=[3,3] or
            attrs.get('pads',[0,0,0,0])!=[0,0,0,0] or
            attrs.get('strides',[1,1])!=[3,3]):
        raise ValueError('unsupported pooled constant geometry')

    conv_w=np.asarray(conv.parameters['weight'],dtype=np.int8)
    zero=np.all(conv_w==0,axis=(1,2,3))
    candidates=np.flatnonzero(zero).tolist()
    if not candidates:
        raise ValueError('no constant final filters')
    cparam=conv.parameters
    cq=program.tensors[conv.output].quantization
    aq_in=program.tensors[act.inputs[0]].quantization
    aq_out=program.tensors[act.output].quantization
    pq_in=program.tensors[pool.inputs[0]].quantization
    pq_out=program.tensors[pool.output].quantization
    gq_in=program.tensors[gemm.inputs[0]].quantization
    if cq!=aq_in or aq_out!=pq_in or pq_out!=gq_in:
        raise ValueError('quantization edge mismatch')
    am,ash=coefficients(aq_in.scale/aq_out.scale)
    pm,psh=coefficients(pq_in.scale/(pq_out.scale*9))
    codes=[]
    for ch in candidates:
        if int(cparam['corrected_bias'][ch])!=int(cparam['bias'][ch]):
            raise ValueError('zero-filter corrected bias differs from bias')
        raw_bias=int(cparam['bias'][ch])
        mul=int(cparam['multiplier'][ch]);shift=int(cparam['shift'][ch])
        conv_code=one_rounded(raw_bias*mul,shift,cq.zero_point)
        act_code=one_rounded((max(aq_in.zero_point,conv_code)-aq_in.zero_point)*am,
                             ash,aq_out.zero_point)
        pool_sum=9*(act_code-pq_in.zero_point)
        pool_code=one_rounded(pool_sum*pm,psh,pq_out.zero_point)
        codes.append(dict(channel=ch,conv_code=conv_code,activation_code=act_code,
                          pool_code=pool_code,reshape_code=pool_code,
                          centered_classifier_input=pool_code-gq_in.zero_point))

    old_weight=np.asarray(gemm.parameters['weight'],dtype=np.int8)
    old_bias=np.asarray(gemm.parameters['bias'],dtype=np.int64)
    old_corrected=np.asarray(gemm.parameters['corrected_bias'],dtype=np.int64)
    if old_weight.shape!=(2,256):
        raise ValueError('classifier weight shape changed')
    old_formula=old_bias-gq_in.zero_point*old_weight.astype(np.int64).sum(axis=1)
    if not np.array_equal(old_corrected,old_formula):
        raise ValueError('original Gemm corrected bias identity failed')
    contribution=np.zeros(2,dtype=np.int64)
    new_weight=old_weight.copy()
    for row in codes:
        ch=row['channel']
        contribution+=row['centered_classifier_input']*old_weight[:,ch].astype(np.int64)
        new_weight[:,ch]=0
    new_bias=old_bias+contribution
    new_corrected=new_bias-gq_in.zero_point*new_weight.astype(np.int64).sum(axis=1)
    flat=new_weight.astype(np.int64)
    raw_bound=np.abs(new_corrected)+128*np.abs(flat).sum(axis=1)
    centered_factor=max(abs(-128-gq_in.zero_point),abs(127-gq_in.zero_point))
    centered_bound=np.abs(new_bias)+centered_factor*np.abs(flat).sum(axis=1)
    if (np.any(new_bias<I32_MIN) or np.any(new_bias>I32_MAX) or
            np.any(new_corrected<I32_MIN) or np.any(new_corrected>I32_MAX) or
            np.any(raw_bound>I32_MAX) or np.any(centered_bound>I32_MAX)):
        raise ValueError('all-input INT32 partial-sum proof failed')
    gemm.parameters['weight']=new_weight
    gemm.parameters['bias']=new_bias.astype('<i4')
    gemm.parameters['corrected_bias']=new_corrected.astype('<i4')
    certificate=dict(schema=1,scope='VWW final Conv 53 -> Relu 54 -> AveragePool 55 -> Reshape 56 -> Gemm 57',
        proof='zero Conv rows imply bias-only requantized code for every input; exact Relu and full 3x3 pool maps are deterministic; Gemm centered contributions move into bias; triangle bounds cover every raw/centered INT32 partial sum',
        constant_channels=len(codes),constant_codes=codes,
        nonzero_classifier_weights_removed=int(np.count_nonzero(old_weight[:,candidates])),
        classifier_input_zero_point=gq_in.zero_point,
        gemm_bias_before=old_bias.tolist(),gemm_bias_delta=contribution.tolist(),
        gemm_bias_after=new_bias.tolist(),
        corrected_bias_before=old_corrected.tolist(),
        corrected_bias_after=new_corrected.tolist(),
        raw_partial_sum_upper_bound=raw_bound.tolist(),
        centered_partial_sum_upper_bound=centered_bound.tolist(),
        accumulator_limit=I32_MAX,
        conv_output_zero_point=cq.zero_point,activation_input_zero_point=aq_in.zero_point,
        activation_output_zero_point=aq_out.zero_point,
        pool_input_zero_point=pq_in.zero_point,pool_output_zero_point=pq_out.zero_point,
        activation_multiplier=am,activation_shift=ash,
        pool_multiplier=pm,pool_shift=psh,
        input_independent=True)
    return program,certificate
