# Autonomous resident controller feasibility

The implementation passes its native correctness campaign but fails the matched FPGA placement gate. The baseline routes at 27 MHz (core Fmax 28.826 MHz, zero setup/hold violations). The candidate uses 20,483/20,736 logic units and all 10,368 clusters; Gowin PR0003 leaves 48 equivalent LUTs unplaced. Candidate routed timing and a usable board image are unavailable.

The isolated sequencer and UART control copies admit one CRC-validated urgent notification while a background inference runs. At a permitted fully drained WAIT, immutable program-SRAM metadata selects precompiled DMA save, urgent AD inference, DMA restore and VWW resumption. No host UART is used after admission. A late accepted request after the last checkpoint executes the urgent job after background HALT. Arithmetic engine, production RTL and compiler files are unchanged.

Original campaign: four policies, fixed RAM and stalled seed 6063, each with uninterrupted control, normal urgent job, full-scratchpad clobber followed by urgent job, and omitted-restore negative control. All 24 positive cases are exact; all eight negative controls detect corruption or an execution error. Four unsafe busy writes are rejected in every run. The normal and artificial clobber latencies are reported separately.

Additional campaign: the same four policies and two RAM modes at 10%, 50%, after the last allowed site and 20 cycles before uninterrupted completion. All 32 runs produce both exact outputs, including 16 completion-fallback cases. Completion-race release uses the same native harness's uninterrupted elapsed count. The last-site release estimate uses a scaled standalone trace, while fallback execution is directly asserted. An initial mismatched stalled completion reference is preserved as a failed diagnostic and corrected in the successful campaign.

Native tests use the v2 UART interface. The separate burst UART copies receive synthesis/placement coverage only. The controller accepts only one outstanding urgent request; it does not implement the queue/admission adapter assumed by the multi-arrival trace model. Tests use VWW background and AD urgent with immutable inputs, not all six task pairs. Neither one sampled stalled RAM mode nor trace replay proves worst-case deadlines. No board or energy measurement was performed.

report.json pins all 64 raw reports, fixtures, native build identity, matched physical reports and 28 bundled sources. native-campaign-report.json retains the original producer metadata. The finalizer adds evidence inventory only; it does not change RTL or rerun experiments. physical/baseline preserves an initial sandbox tool crash separately from the successful approved route.

Commands, from project root:

```
.venv/bin/python3 tools/phase6/deadline_resident.py native --fixtures work/phase6/deadline-policy-v1/resident/vww-ad-{baseline,split25000,split50000,selective-long25000}
.venv/bin/python3 tools/phase6/deadline_resident.py arrivals --fixtures work/phase6/deadline-policy-v1/resident/vww-ad-{baseline,split25000,split50000,selective-long25000}
.venv/bin/python3 tools/phase6/deadline_resident.py route --mode baseline
.venv/bin/python3 tools/phase6/deadline_resident.py route --mode candidate
.venv/bin/python3 tools/phase6/finalize_decision_round.py
```

Native builds use two jobs; route runs are serialized. The current prototype is not suitable for board evaluation. Native correctness is useful engineering evidence, and does not establish a new mechanism beyond the prior art reviewed in the decision report.
